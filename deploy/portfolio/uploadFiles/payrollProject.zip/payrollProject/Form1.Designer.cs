﻿//CECS 475 
//Jesus Contreras

using System;
using System.Web;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace PayrollSystem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.paymentTab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.CloseButton1 = new System.Windows.Forms.Button();
            this.ssnSearchView1 = new System.Windows.Forms.ListView();
            this.ssnColumnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ssnColumnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ssnColumnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ssnColumnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ssnSearchTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.ssnSearchbutton1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.EmployeeListView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.c = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.EmployeeDatabaselabel3 = new System.Windows.Forms.Label();
            this.closeButton2 = new System.Windows.Forms.Button();
            this.sortGroupBox1 = new System.Windows.Forms.GroupBox();
            this.sortButton1 = new System.Windows.Forms.Button();
            this.payDesRadioButton4 = new System.Windows.Forms.RadioButton();
            this.payAscRadioButton3 = new System.Windows.Forms.RadioButton();
            this.sortLnRadioButton2 = new System.Windows.Forms.RadioButton();
            this.sortBySsnRadioButton1 = new System.Windows.Forms.RadioButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.generalInfoGroupBox1 = new System.Windows.Forms.GroupBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.addEmployeebutton1 = new System.Windows.Forms.Button();
            this.addSalariedLabel6 = new System.Windows.Forms.Label();
            this.addSalariedTextBox1 = new System.Windows.Forms.TextBox();
            this.addSalariedRadioButton1 = new System.Windows.Forms.RadioButton();
            this.addComissiongroupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.addBaseTextBox1 = new System.Windows.Forms.TextBox();
            this.baseComRadioButton2 = new System.Windows.Forms.RadioButton();
            this.adSalesLabel6 = new System.Windows.Forms.Label();
            this.addComissionLabel7 = new System.Windows.Forms.Label();
            this.addComissionTextBox1 = new System.Windows.Forms.TextBox();
            this.addSalesTextBox2 = new System.Windows.Forms.TextBox();
            this.addComissionRadioButton1 = new System.Windows.Forms.RadioButton();
            this.AddHours = new System.Windows.Forms.Label();
            this.Rate = new System.Windows.Forms.Label();
            this.addHourRateTextBox2 = new System.Windows.Forms.TextBox();
            this.addHoursTextBox1 = new System.Windows.Forms.TextBox();
            this.addHourlyRadioButton1 = new System.Windows.Forms.RadioButton();
            this.employeeTypesLabel6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.AddSsnLabel5 = new System.Windows.Forms.Label();
            this.AddLastNameLabel5 = new System.Windows.Forms.Label();
            this.addLastNameTextBox1 = new System.Windows.Forms.TextBox();
            this.adFirstNamelabel5 = new System.Windows.Forms.Label();
            this.addFirstNametextBox1 = new System.Windows.Forms.TextBox();
            this.PleaseInsertlabel5 = new System.Windows.Forms.Label();
            this.addEmployeeLabel5 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.payListView1 = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button3 = new System.Windows.Forms.Button();
            this.PayInfoGroupBox1 = new System.Windows.Forms.GroupBox();
            this.allPayRadioButton1 = new System.Windows.Forms.RadioButton();
            this.displayPayButton1 = new System.Windows.Forms.Button();
            this.BaseComPayRadioButton1 = new System.Windows.Forms.RadioButton();
            this.ComisPayRadioButton3 = new System.Windows.Forms.RadioButton();
            this.hourPayRadioButton4 = new System.Windows.Forms.RadioButton();
            this.salaryPayInforadioButton5 = new System.Windows.Forms.RadioButton();
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.paymentTab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.sortGroupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.generalInfoGroupBox1.SuspendLayout();
            this.addComissiongroupBox2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.PayInfoGroupBox1.SuspendLayout();
            this.menuStrip3.SuspendLayout();
            this.SuspendLayout();
            // 
            // paymentTab
            // 
            this.paymentTab.Controls.Add(this.tabPage1);
            this.paymentTab.Controls.Add(this.tabPage2);
            this.paymentTab.Controls.Add(this.tabPage3);
            this.paymentTab.Controls.Add(this.tabPage4);
            this.paymentTab.Location = new System.Drawing.Point(0, 27);
            this.paymentTab.Name = "paymentTab";
            this.paymentTab.SelectedIndex = 0;
            this.paymentTab.Size = new System.Drawing.Size(594, 558);
            this.paymentTab.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.Controls.Add(this.CloseButton1);
            this.tabPage1.Controls.Add(this.ssnSearchView1);
            this.tabPage1.Controls.Add(this.ssnSearchTextBox1);
            this.tabPage1.Controls.Add(this.ssnSearchbutton1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(586, 532);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Search Employee";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // CloseButton1
            // 
            this.CloseButton1.Location = new System.Drawing.Point(486, 494);
            this.CloseButton1.Name = "CloseButton1";
            this.CloseButton1.Size = new System.Drawing.Size(94, 26);
            this.CloseButton1.TabIndex = 6;
            this.CloseButton1.Text = "Close";
            this.CloseButton1.UseVisualStyleBackColor = true;
            this.CloseButton1.Click += new System.EventHandler(this.CloseButton1_Click);
            // 
            // ssnSearchView1
            // 
            this.ssnSearchView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ssnColumnHeader1,
            this.ssnColumnHeader2,
            this.ssnColumnHeader3,
            this.ssnColumnHeader4});
            this.ssnSearchView1.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.ssnSearchView1.Location = new System.Drawing.Point(21, 126);
            this.ssnSearchView1.Name = "ssnSearchView1";
            this.ssnSearchView1.Size = new System.Drawing.Size(539, 216);
            this.ssnSearchView1.TabIndex = 5;
            this.ssnSearchView1.UseCompatibleStateImageBehavior = false;
            this.ssnSearchView1.View = System.Windows.Forms.View.Details;
            this.ssnSearchView1.SelectedIndexChanged += new System.EventHandler(this.ssnSearchView1_SelectedIndexChanged);
            // 
            // ssnColumnHeader1
            // 
            this.ssnColumnHeader1.Text = "First Name";
            this.ssnColumnHeader1.Width = 137;
            // 
            // ssnColumnHeader2
            // 
            this.ssnColumnHeader2.Text = "Last Name";
            this.ssnColumnHeader2.Width = 154;
            // 
            // ssnColumnHeader3
            // 
            this.ssnColumnHeader3.Text = "Social Security Number";
            this.ssnColumnHeader3.Width = 131;
            // 
            // ssnColumnHeader4
            // 
            this.ssnColumnHeader4.Text = "Total Pay";
            this.ssnColumnHeader4.Width = 111;
            // 
            // ssnSearchTextBox1
            // 
            this.ssnSearchTextBox1.Location = new System.Drawing.Point(24, 82);
            this.ssnSearchTextBox1.Mask = "000-00-0000";
            this.ssnSearchTextBox1.Name = "ssnSearchTextBox1";
            this.ssnSearchTextBox1.Size = new System.Drawing.Size(164, 20);
            this.ssnSearchTextBox1.TabIndex = 4;
            this.ssnSearchTextBox1.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.ssnSearchTextBox1_MaskInputRejected);
            // 
            // ssnSearchbutton1
            // 
            this.ssnSearchbutton1.Location = new System.Drawing.Point(194, 77);
            this.ssnSearchbutton1.Name = "ssnSearchbutton1";
            this.ssnSearchbutton1.Size = new System.Drawing.Size(65, 26);
            this.ssnSearchbutton1.TabIndex = 3;
            this.ssnSearchbutton1.Text = "Search";
            this.ssnSearchbutton1.UseVisualStyleBackColor = true;
            this.ssnSearchbutton1.Click += new System.EventHandler(this.ssnSearchbutton1_Click);
            this.ssnSearchbutton1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CheckKeys);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(238, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Search For Employee by Inserting Social Security";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(18, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee Payroll Systems (EPS)";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage2.Controls.Add(this.EmployeeListView1);
            this.tabPage2.Controls.Add(this.c);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.EmployeeDatabaselabel3);
            this.tabPage2.Controls.Add(this.closeButton2);
            this.tabPage2.Controls.Add(this.sortGroupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(586, 532);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Employee Info";
            // 
            // EmployeeListView1
            // 
            this.EmployeeListView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.EmployeeListView1.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.EmployeeListView1.Location = new System.Drawing.Point(5, 102);
            this.EmployeeListView1.Name = "EmployeeListView1";
            this.EmployeeListView1.Size = new System.Drawing.Size(177, 378);
            this.EmployeeListView1.TabIndex = 12;
            this.EmployeeListView1.UseCompatibleStateImageBehavior = false;
            this.EmployeeListView1.View = System.Windows.Forms.View.Details;
            this.EmployeeListView1.ItemActivate += new System.EventHandler(this.EmployeeListView1_ItemActivate);
            this.EmployeeListView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Full Name";
            this.columnHeader1.Width = 178;
            // 
            // c
            // 
            this.c.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
            this.c.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.c.Location = new System.Drawing.Point(188, 102);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(384, 190);
            this.c.TabIndex = 11;
            this.c.UseCompatibleStateImageBehavior = false;
            this.c.View = System.Windows.Forms.View.Details;
            this.c.SelectedIndexChanged += new System.EventHandler(this.EmployeeInfoListView1_SelectedIndexChanged);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "First Name";
            this.columnHeader4.Width = 94;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Last Name";
            this.columnHeader5.Width = 90;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Social Security Number";
            this.columnHeader6.Width = 122;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Total Pay";
            this.columnHeader7.Width = 74;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(185, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Employee Information";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Employee Name";
            // 
            // EmployeeDatabaselabel3
            // 
            this.EmployeeDatabaselabel3.AutoSize = true;
            this.EmployeeDatabaselabel3.Location = new System.Drawing.Point(7, 23);
            this.EmployeeDatabaselabel3.Name = "EmployeeDatabaselabel3";
            this.EmployeeDatabaselabel3.Size = new System.Drawing.Size(102, 13);
            this.EmployeeDatabaselabel3.TabIndex = 5;
            this.EmployeeDatabaselabel3.Text = "Employee Database";
            // 
            // closeButton2
            // 
            this.closeButton2.Location = new System.Drawing.Point(503, 503);
            this.closeButton2.Name = "closeButton2";
            this.closeButton2.Size = new System.Drawing.Size(75, 23);
            this.closeButton2.TabIndex = 3;
            this.closeButton2.Text = "Close";
            this.closeButton2.UseVisualStyleBackColor = true;
            this.closeButton2.Click += new System.EventHandler(this.closeButton2_Click);
            // 
            // sortGroupBox1
            // 
            this.sortGroupBox1.Controls.Add(this.sortButton1);
            this.sortGroupBox1.Controls.Add(this.payDesRadioButton4);
            this.sortGroupBox1.Controls.Add(this.payAscRadioButton3);
            this.sortGroupBox1.Controls.Add(this.sortLnRadioButton2);
            this.sortGroupBox1.Controls.Add(this.sortBySsnRadioButton1);
            this.sortGroupBox1.Location = new System.Drawing.Point(428, 302);
            this.sortGroupBox1.Name = "sortGroupBox1";
            this.sortGroupBox1.Size = new System.Drawing.Size(144, 178);
            this.sortGroupBox1.TabIndex = 2;
            this.sortGroupBox1.TabStop = false;
            this.sortGroupBox1.Text = "Sort And Display All Employee Data By";
            this.sortGroupBox1.Enter += new System.EventHandler(this.sortGroupBox1_Enter);
            // 
            // sortButton1
            // 
            this.sortButton1.Location = new System.Drawing.Point(37, 140);
            this.sortButton1.Name = "sortButton1";
            this.sortButton1.Size = new System.Drawing.Size(75, 23);
            this.sortButton1.TabIndex = 4;
            this.sortButton1.Text = "Sort";
            this.sortButton1.UseVisualStyleBackColor = true;
            this.sortButton1.Click += new System.EventHandler(this.sortButton1_Click);
            // 
            // payDesRadioButton4
            // 
            this.payDesRadioButton4.AutoSize = true;
            this.payDesRadioButton4.Location = new System.Drawing.Point(6, 102);
            this.payDesRadioButton4.Name = "payDesRadioButton4";
            this.payDesRadioButton4.Size = new System.Drawing.Size(136, 17);
            this.payDesRadioButton4.TabIndex = 3;
            this.payDesRadioButton4.TabStop = true;
            this.payDesRadioButton4.Text = "Total Pay (Descending)";
            this.payDesRadioButton4.UseVisualStyleBackColor = true;
            this.payDesRadioButton4.CheckedChanged += new System.EventHandler(this.payDesRadioButton4_CheckedChanged);
            // 
            // payAscRadioButton3
            // 
            this.payAscRadioButton3.AutoSize = true;
            this.payAscRadioButton3.Location = new System.Drawing.Point(5, 79);
            this.payAscRadioButton3.Name = "payAscRadioButton3";
            this.payAscRadioButton3.Size = new System.Drawing.Size(129, 17);
            this.payAscRadioButton3.TabIndex = 2;
            this.payAscRadioButton3.TabStop = true;
            this.payAscRadioButton3.Text = "Total Pay (Ascending)";
            this.payAscRadioButton3.UseVisualStyleBackColor = true;
            this.payAscRadioButton3.CheckedChanged += new System.EventHandler(this.payAscRadioButton3_CheckedChanged);
            // 
            // sortLnRadioButton2
            // 
            this.sortLnRadioButton2.AutoSize = true;
            this.sortLnRadioButton2.Location = new System.Drawing.Point(5, 56);
            this.sortLnRadioButton2.Name = "sortLnRadioButton2";
            this.sortLnRadioButton2.Size = new System.Drawing.Size(76, 17);
            this.sortLnRadioButton2.TabIndex = 1;
            this.sortLnRadioButton2.TabStop = true;
            this.sortLnRadioButton2.Text = "Last Name";
            this.sortLnRadioButton2.UseVisualStyleBackColor = true;
            this.sortLnRadioButton2.CheckedChanged += new System.EventHandler(this.sortLnRadioButton2_CheckedChanged);
            // 
            // sortBySsnRadioButton1
            // 
            this.sortBySsnRadioButton1.AutoSize = true;
            this.sortBySsnRadioButton1.Location = new System.Drawing.Point(5, 33);
            this.sortBySsnRadioButton1.Name = "sortBySsnRadioButton1";
            this.sortBySsnRadioButton1.Size = new System.Drawing.Size(135, 17);
            this.sortBySsnRadioButton1.TabIndex = 0;
            this.sortBySsnRadioButton1.Text = "Social Security Number";
            this.sortBySsnRadioButton1.UseVisualStyleBackColor = true;
            this.sortBySsnRadioButton1.CheckedChanged += new System.EventHandler(this.sortBySsnRadioButton1_CheckedChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.generalInfoGroupBox1);
            this.tabPage3.Controls.Add(this.PleaseInsertlabel5);
            this.tabPage3.Controls.Add(this.addEmployeeLabel5);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(586, 532);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Add Employee ";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(501, 501);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // generalInfoGroupBox1
            // 
            this.generalInfoGroupBox1.Controls.Add(this.maskedTextBox1);
            this.generalInfoGroupBox1.Controls.Add(this.addEmployeebutton1);
            this.generalInfoGroupBox1.Controls.Add(this.addComissiongroupBox2);
            this.generalInfoGroupBox1.Controls.Add(this.employeeTypesLabel6);
            this.generalInfoGroupBox1.Controls.Add(this.label5);
            this.generalInfoGroupBox1.Controls.Add(this.AddSsnLabel5);
            this.generalInfoGroupBox1.Controls.Add(this.AddLastNameLabel5);
            this.generalInfoGroupBox1.Controls.Add(this.addLastNameTextBox1);
            this.generalInfoGroupBox1.Controls.Add(this.adFirstNamelabel5);
            this.generalInfoGroupBox1.Controls.Add(this.addFirstNametextBox1);
            this.generalInfoGroupBox1.Location = new System.Drawing.Point(15, 44);
            this.generalInfoGroupBox1.Name = "generalInfoGroupBox1";
            this.generalInfoGroupBox1.Size = new System.Drawing.Size(256, 480);
            this.generalInfoGroupBox1.TabIndex = 2;
            this.generalInfoGroupBox1.TabStop = false;
            this.generalInfoGroupBox1.Text = "Employee Infomation";
            this.generalInfoGroupBox1.Enter += new System.EventHandler(this.generalInfoGroupBox1_Enter);
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(6, 121);
            this.maskedTextBox1.Mask = "000-00-0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(194, 20);
            this.maskedTextBox1.TabIndex = 5;
            this.maskedTextBox1.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox1_MaskInputRejected);
            // 
            // addEmployeebutton1
            // 
            this.addEmployeebutton1.Location = new System.Drawing.Point(143, 451);
            this.addEmployeebutton1.Name = "addEmployeebutton1";
            this.addEmployeebutton1.Size = new System.Drawing.Size(106, 23);
            this.addEmployeebutton1.TabIndex = 10;
            this.addEmployeebutton1.Text = "Add Employee";
            this.addEmployeebutton1.UseVisualStyleBackColor = true;
            this.addEmployeebutton1.Click += new System.EventHandler(this.addEmployeebutton1_Click);
            // 
            // addSalariedLabel6
            // 
            this.addSalariedLabel6.AutoSize = true;
            this.addSalariedLabel6.Location = new System.Drawing.Point(134, 204);
            this.addSalariedLabel6.Name = "addSalariedLabel6";
            this.addSalariedLabel6.Size = new System.Drawing.Size(36, 13);
            this.addSalariedLabel6.TabIndex = 7;
            this.addSalariedLabel6.Text = "Salary";
            // 
            // addSalariedTextBox1
            // 
            this.addSalariedTextBox1.Location = new System.Drawing.Point(137, 220);
            this.addSalariedTextBox1.Name = "addSalariedTextBox1";
            this.addSalariedTextBox1.Size = new System.Drawing.Size(77, 20);
            this.addSalariedTextBox1.TabIndex = 6;
            this.addSalariedTextBox1.TextChanged += new System.EventHandler(this.addSalariedTextBox1_TextChanged);
            // 
            // addSalariedRadioButton1
            // 
            this.addSalariedRadioButton1.AutoSize = true;
            this.addSalariedRadioButton1.Location = new System.Drawing.Point(9, 220);
            this.addSalariedRadioButton1.Name = "addSalariedRadioButton1";
            this.addSalariedRadioButton1.Size = new System.Drawing.Size(63, 17);
            this.addSalariedRadioButton1.TabIndex = 0;
            this.addSalariedRadioButton1.TabStop = true;
            this.addSalariedRadioButton1.Text = "Salaried";
            this.addSalariedRadioButton1.UseVisualStyleBackColor = true;
            this.addSalariedRadioButton1.CheckedChanged += new System.EventHandler(this.addSalariedRadioButton1_CheckedChanged);
            // 
            // addComissiongroupBox2
            // 
            this.addComissiongroupBox2.Controls.Add(this.addSalariedLabel6);
            this.addComissiongroupBox2.Controls.Add(this.label9);
            this.addComissiongroupBox2.Controls.Add(this.addSalariedTextBox1);
            this.addComissiongroupBox2.Controls.Add(this.label8);
            this.addComissiongroupBox2.Controls.Add(this.addSalariedRadioButton1);
            this.addComissiongroupBox2.Controls.Add(this.addHoursTextBox1);
            this.addComissiongroupBox2.Controls.Add(this.AddHours);
            this.addComissiongroupBox2.Controls.Add(this.label6);
            this.addComissiongroupBox2.Controls.Add(this.addBaseTextBox1);
            this.addComissiongroupBox2.Controls.Add(this.baseComRadioButton2);
            this.addComissiongroupBox2.Controls.Add(this.adSalesLabel6);
            this.addComissiongroupBox2.Controls.Add(this.addComissionLabel7);
            this.addComissiongroupBox2.Controls.Add(this.addHourRateTextBox2);
            this.addComissiongroupBox2.Controls.Add(this.addComissionTextBox1);
            this.addComissiongroupBox2.Controls.Add(this.addSalesTextBox2);
            this.addComissiongroupBox2.Controls.Add(this.Rate);
            this.addComissiongroupBox2.Controls.Add(this.addComissionRadioButton1);
            this.addComissiongroupBox2.Controls.Add(this.addHourlyRadioButton1);
            this.addComissiongroupBox2.Location = new System.Drawing.Point(6, 179);
            this.addComissiongroupBox2.Name = "addComissiongroupBox2";
            this.addComissiongroupBox2.Size = new System.Drawing.Size(232, 266);
            this.addComissiongroupBox2.TabIndex = 9;
            this.addComissiongroupBox2.TabStop = false;
            this.addComissiongroupBox2.Text = "Comissioned Employee";
            this.addComissiongroupBox2.Enter += new System.EventHandler(this.addComissiongroupBox2_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(154, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Base Pay";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // addBaseTextBox1
            // 
            this.addBaseTextBox1.Location = new System.Drawing.Point(157, 69);
            this.addBaseTextBox1.Name = "addBaseTextBox1";
            this.addBaseTextBox1.Size = new System.Drawing.Size(66, 20);
            this.addBaseTextBox1.TabIndex = 6;
            // 
            // baseComRadioButton2
            // 
            this.baseComRadioButton2.AutoSize = true;
            this.baseComRadioButton2.Location = new System.Drawing.Point(100, 19);
            this.baseComRadioButton2.Name = "baseComRadioButton2";
            this.baseComRadioButton2.Size = new System.Drawing.Size(123, 17);
            this.baseComRadioButton2.TabIndex = 5;
            this.baseComRadioButton2.TabStop = true;
            this.baseComRadioButton2.Text = " Base and Comission";
            this.baseComRadioButton2.UseVisualStyleBackColor = true;
            this.baseComRadioButton2.CheckedChanged += new System.EventHandler(this.baseComRadioButton2_CheckedChanged);
            // 
            // adSalesLabel6
            // 
            this.adSalesLabel6.AutoSize = true;
            this.adSalesLabel6.Location = new System.Drawing.Point(80, 53);
            this.adSalesLabel6.Name = "adSalesLabel6";
            this.adSalesLabel6.Size = new System.Drawing.Size(33, 13);
            this.adSalesLabel6.TabIndex = 4;
            this.adSalesLabel6.Text = "Sales";
            // 
            // addComissionLabel7
            // 
            this.addComissionLabel7.AutoSize = true;
            this.addComissionLabel7.Location = new System.Drawing.Point(6, 53);
            this.addComissionLabel7.Name = "addComissionLabel7";
            this.addComissionLabel7.Size = new System.Drawing.Size(54, 13);
            this.addComissionLabel7.TabIndex = 3;
            this.addComissionLabel7.Text = "Comission";
            // 
            // addComissionTextBox1
            // 
            this.addComissionTextBox1.Location = new System.Drawing.Point(6, 69);
            this.addComissionTextBox1.Name = "addComissionTextBox1";
            this.addComissionTextBox1.Size = new System.Drawing.Size(66, 20);
            this.addComissionTextBox1.TabIndex = 2;
            this.addComissionTextBox1.TextChanged += new System.EventHandler(this.addComissionTextBox1_TextChanged);
            // 
            // addSalesTextBox2
            // 
            this.addSalesTextBox2.Location = new System.Drawing.Point(81, 69);
            this.addSalesTextBox2.Name = "addSalesTextBox2";
            this.addSalesTextBox2.Size = new System.Drawing.Size(67, 20);
            this.addSalesTextBox2.TabIndex = 1;
            this.addSalesTextBox2.TextChanged += new System.EventHandler(this.addSalesTextBox2_TextChanged);
            // 
            // addComissionRadioButton1
            // 
            this.addComissionRadioButton1.AutoSize = true;
            this.addComissionRadioButton1.Location = new System.Drawing.Point(9, 19);
            this.addComissionRadioButton1.Name = "addComissionRadioButton1";
            this.addComissionRadioButton1.Size = new System.Drawing.Size(72, 17);
            this.addComissionRadioButton1.TabIndex = 0;
            this.addComissionRadioButton1.TabStop = true;
            this.addComissionRadioButton1.Text = "Comission";
            this.addComissionRadioButton1.UseVisualStyleBackColor = true;
            this.addComissionRadioButton1.CheckedChanged += new System.EventHandler(this.addComissionRadioButton1_CheckedChanged);
            // 
            // AddHours
            // 
            this.AddHours.AutoSize = true;
            this.AddHours.Location = new System.Drawing.Point(143, 137);
            this.AddHours.Name = "AddHours";
            this.AddHours.Size = new System.Drawing.Size(76, 13);
            this.AddHours.TabIndex = 4;
            this.AddHours.Text = "Hours Worked";
            // 
            // Rate
            // 
            this.Rate.AutoSize = true;
            this.Rate.Location = new System.Drawing.Point(3, 137);
            this.Rate.Name = "Rate";
            this.Rate.Size = new System.Drawing.Size(75, 13);
            this.Rate.TabIndex = 3;
            this.Rate.Text = "Rate Per Hour";
            // 
            // addHourRateTextBox2
            // 
            this.addHourRateTextBox2.Location = new System.Drawing.Point(4, 153);
            this.addHourRateTextBox2.Name = "addHourRateTextBox2";
            this.addHourRateTextBox2.Size = new System.Drawing.Size(77, 20);
            this.addHourRateTextBox2.TabIndex = 2;
            this.addHourRateTextBox2.TextChanged += new System.EventHandler(this.addHourRateTextBox2_TextChanged);
            // 
            // addHoursTextBox1
            // 
            this.addHoursTextBox1.Location = new System.Drawing.Point(146, 153);
            this.addHoursTextBox1.Name = "addHoursTextBox1";
            this.addHoursTextBox1.Size = new System.Drawing.Size(77, 20);
            this.addHoursTextBox1.TabIndex = 1;
            this.addHoursTextBox1.TextChanged += new System.EventHandler(this.addHoursTextBox1_TextChanged);
            // 
            // addHourlyRadioButton1
            // 
            this.addHourlyRadioButton1.AutoSize = true;
            this.addHourlyRadioButton1.Location = new System.Drawing.Point(6, 111);
            this.addHourlyRadioButton1.Name = "addHourlyRadioButton1";
            this.addHourlyRadioButton1.Size = new System.Drawing.Size(104, 17);
            this.addHourlyRadioButton1.TabIndex = 0;
            this.addHourlyRadioButton1.TabStop = true;
            this.addHourlyRadioButton1.Text = "Hourly Employee";
            this.addHourlyRadioButton1.UseVisualStyleBackColor = true;
            this.addHourlyRadioButton1.CheckedChanged += new System.EventHandler(this.addHourlyRadioButton1_CheckedChanged);
            // 
            // employeeTypesLabel6
            // 
            this.employeeTypesLabel6.AutoSize = true;
            this.employeeTypesLabel6.Location = new System.Drawing.Point(7, 163);
            this.employeeTypesLabel6.Name = "employeeTypesLabel6";
            this.employeeTypesLabel6.Size = new System.Drawing.Size(247, 13);
            this.employeeTypesLabel6.TabIndex = 7;
            this.employeeTypesLabel6.Text = "---EmployeeTypes----------------------------------------------------";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label5.Location = new System.Drawing.Point(3, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(246, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Select Only One Type of Employee and Input Data";
            // 
            // AddSsnLabel5
            // 
            this.AddSsnLabel5.AutoSize = true;
            this.AddSsnLabel5.Location = new System.Drawing.Point(7, 104);
            this.AddSsnLabel5.Name = "AddSsnLabel5";
            this.AddSsnLabel5.Size = new System.Drawing.Size(117, 13);
            this.AddSsnLabel5.TabIndex = 5;
            this.AddSsnLabel5.Text = "Social Security Number";
            // 
            // AddLastNameLabel5
            // 
            this.AddLastNameLabel5.AutoSize = true;
            this.AddLastNameLabel5.Location = new System.Drawing.Point(6, 63);
            this.AddLastNameLabel5.Name = "AddLastNameLabel5";
            this.AddLastNameLabel5.Size = new System.Drawing.Size(58, 13);
            this.AddLastNameLabel5.TabIndex = 4;
            this.AddLastNameLabel5.Text = "Last Name";
            // 
            // addLastNameTextBox1
            // 
            this.addLastNameTextBox1.Location = new System.Drawing.Point(6, 82);
            this.addLastNameTextBox1.Name = "addLastNameTextBox1";
            this.addLastNameTextBox1.Size = new System.Drawing.Size(194, 20);
            this.addLastNameTextBox1.TabIndex = 2;
            this.addLastNameTextBox1.TextChanged += new System.EventHandler(this.addLastNameTextBox1_TextChanged);
            // 
            // adFirstNamelabel5
            // 
            this.adFirstNamelabel5.AutoSize = true;
            this.adFirstNamelabel5.Location = new System.Drawing.Point(7, 21);
            this.adFirstNamelabel5.Name = "adFirstNamelabel5";
            this.adFirstNamelabel5.Size = new System.Drawing.Size(57, 13);
            this.adFirstNamelabel5.TabIndex = 1;
            this.adFirstNamelabel5.Text = "First Name";
            // 
            // addFirstNametextBox1
            // 
            this.addFirstNametextBox1.Location = new System.Drawing.Point(6, 40);
            this.addFirstNametextBox1.Name = "addFirstNametextBox1";
            this.addFirstNametextBox1.Size = new System.Drawing.Size(194, 20);
            this.addFirstNametextBox1.TabIndex = 0;
            this.addFirstNametextBox1.TextChanged += new System.EventHandler(this.addFirstNametextBox1_TextChanged);
            // 
            // PleaseInsertlabel5
            // 
            this.PleaseInsertlabel5.AutoSize = true;
            this.PleaseInsertlabel5.ForeColor = System.Drawing.Color.Gray;
            this.PleaseInsertlabel5.Location = new System.Drawing.Point(8, 28);
            this.PleaseInsertlabel5.Name = "PleaseInsertlabel5";
            this.PleaseInsertlabel5.Size = new System.Drawing.Size(263, 13);
            this.PleaseInsertlabel5.TabIndex = 1;
            this.PleaseInsertlabel5.Text = "Please Enter the Follwing Information on the Employee";
            // 
            // addEmployeeLabel5
            // 
            this.addEmployeeLabel5.AutoSize = true;
            this.addEmployeeLabel5.Location = new System.Drawing.Point(8, 10);
            this.addEmployeeLabel5.Name = "addEmployeeLabel5";
            this.addEmployeeLabel5.Size = new System.Drawing.Size(196, 13);
            this.addEmployeeLabel5.TabIndex = 0;
            this.addEmployeeLabel5.Text = "Add An Employee To the Payroll System";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage4.Controls.Add(this.pictureBox1);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.payListView1);
            this.tabPage4.Controls.Add(this.button3);
            this.tabPage4.Controls.Add(this.PayInfoGroupBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(586, 532);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Payroll Payment Info";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PayrollSystem.Properties.Resources.money;
            this.pictureBox1.Location = new System.Drawing.Point(21, 247);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(206, 273);
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(221, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Collective Payment Information for Employees";
            // 
            // payListView1
            // 
            this.payListView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2});
            this.payListView1.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.payListView1.Location = new System.Drawing.Point(9, 51);
            this.payListView1.Name = "payListView1";
            this.payListView1.Size = new System.Drawing.Size(564, 190);
            this.payListView1.TabIndex = 12;
            this.payListView1.UseCompatibleStateImageBehavior = false;
            this.payListView1.View = System.Windows.Forms.View.Details;
            this.payListView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged_1);
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Total Pay";
            this.columnHeader2.Width = 590;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(498, 497);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "Close";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // PayInfoGroupBox1
            // 
            this.PayInfoGroupBox1.Controls.Add(this.allPayRadioButton1);
            this.PayInfoGroupBox1.Controls.Add(this.displayPayButton1);
            this.PayInfoGroupBox1.Controls.Add(this.BaseComPayRadioButton1);
            this.PayInfoGroupBox1.Controls.Add(this.ComisPayRadioButton3);
            this.PayInfoGroupBox1.Controls.Add(this.hourPayRadioButton4);
            this.PayInfoGroupBox1.Controls.Add(this.salaryPayInforadioButton5);
            this.PayInfoGroupBox1.Location = new System.Drawing.Point(429, 268);
            this.PayInfoGroupBox1.Name = "PayInfoGroupBox1";
            this.PayInfoGroupBox1.Size = new System.Drawing.Size(144, 211);
            this.PayInfoGroupBox1.TabIndex = 6;
            this.PayInfoGroupBox1.TabStop = false;
            this.PayInfoGroupBox1.Text = "Display Collective Payment Information For All Employees Of Type";
            // 
            // allPayRadioButton1
            // 
            this.allPayRadioButton1.AutoSize = true;
            this.allPayRadioButton1.Location = new System.Drawing.Point(6, 136);
            this.allPayRadioButton1.Name = "allPayRadioButton1";
            this.allPayRadioButton1.Size = new System.Drawing.Size(96, 17);
            this.allPayRadioButton1.TabIndex = 5;
            this.allPayRadioButton1.TabStop = true;
            this.allPayRadioButton1.Text = "All (Employees)";
            this.allPayRadioButton1.UseVisualStyleBackColor = true;
            // 
            // displayPayButton1
            // 
            this.displayPayButton1.Location = new System.Drawing.Point(36, 171);
            this.displayPayButton1.Name = "displayPayButton1";
            this.displayPayButton1.Size = new System.Drawing.Size(75, 23);
            this.displayPayButton1.TabIndex = 4;
            this.displayPayButton1.Text = "Calculate";
            this.displayPayButton1.UseVisualStyleBackColor = true;
            this.displayPayButton1.Click += new System.EventHandler(this.displayPayButton1_Click_1);
            // 
            // BaseComPayRadioButton1
            // 
            this.BaseComPayRadioButton1.AutoSize = true;
            this.BaseComPayRadioButton1.Location = new System.Drawing.Point(6, 113);
            this.BaseComPayRadioButton1.Name = "BaseComPayRadioButton1";
            this.BaseComPayRadioButton1.Size = new System.Drawing.Size(119, 17);
            this.BaseComPayRadioButton1.TabIndex = 3;
            this.BaseComPayRadioButton1.TabStop = true;
            this.BaseComPayRadioButton1.Text = "Base + Commission ";
            this.BaseComPayRadioButton1.UseVisualStyleBackColor = true;
            this.BaseComPayRadioButton1.CheckedChanged += new System.EventHandler(this.BaseComPayRadioButton1_CheckedChanged);
            // 
            // ComisPayRadioButton3
            // 
            this.ComisPayRadioButton3.AutoSize = true;
            this.ComisPayRadioButton3.Location = new System.Drawing.Point(5, 90);
            this.ComisPayRadioButton3.Name = "ComisPayRadioButton3";
            this.ComisPayRadioButton3.Size = new System.Drawing.Size(72, 17);
            this.ComisPayRadioButton3.TabIndex = 2;
            this.ComisPayRadioButton3.TabStop = true;
            this.ComisPayRadioButton3.Text = "Comission";
            this.ComisPayRadioButton3.UseVisualStyleBackColor = true;
            // 
            // hourPayRadioButton4
            // 
            this.hourPayRadioButton4.AutoSize = true;
            this.hourPayRadioButton4.Location = new System.Drawing.Point(6, 67);
            this.hourPayRadioButton4.Name = "hourPayRadioButton4";
            this.hourPayRadioButton4.Size = new System.Drawing.Size(55, 17);
            this.hourPayRadioButton4.TabIndex = 1;
            this.hourPayRadioButton4.TabStop = true;
            this.hourPayRadioButton4.Text = "Hourly";
            this.hourPayRadioButton4.UseVisualStyleBackColor = true;
            // 
            // salaryPayInforadioButton5
            // 
            this.salaryPayInforadioButton5.AutoSize = true;
            this.salaryPayInforadioButton5.Location = new System.Drawing.Point(6, 44);
            this.salaryPayInforadioButton5.Name = "salaryPayInforadioButton5";
            this.salaryPayInforadioButton5.Size = new System.Drawing.Size(57, 17);
            this.salaryPayInforadioButton5.TabIndex = 0;
            this.salaryPayInforadioButton5.Text = "Salary ";
            this.salaryPayInforadioButton5.UseVisualStyleBackColor = true;
            // 
            // toolTip2
            // 
            this.toolTip2.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip2_Popup);
            // 
            // toolTip1
            // 
            this.toolTip1.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip1_Popup);
            // 
            // menuStrip3
            // 
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem});
            this.menuStrip3.Location = new System.Drawing.Point(0, 0);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(594, 24);
            this.menuStrip3.TabIndex = 2;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label8.Location = new System.Drawing.Point(0, 89);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(229, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "_____________________________________";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label9.Location = new System.Drawing.Point(0, 176);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(229, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "_____________________________________";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 581);
            this.Controls.Add(this.paymentTab);
            this.Controls.Add(this.menuStrip3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "PayrollSystems";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.paymentTab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.sortGroupBox1.ResumeLayout(false);
            this.sortGroupBox1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.generalInfoGroupBox1.ResumeLayout(false);
            this.generalInfoGroupBox1.PerformLayout();
            this.addComissiongroupBox2.ResumeLayout(false);
            this.addComissiongroupBox2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.PayInfoGroupBox1.ResumeLayout(false);
            this.PayInfoGroupBox1.PerformLayout();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl paymentTab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView ssnSearchView1;
        private System.Windows.Forms.MaskedTextBox ssnSearchTextBox1;
        private System.Windows.Forms.Button ssnSearchbutton1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button CloseButton1;
        private System.Windows.Forms.Button closeButton2;
        private System.Windows.Forms.Label EmployeeDatabaselabel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox generalInfoGroupBox1;
        private System.Windows.Forms.Label PleaseInsertlabel5;
        private System.Windows.Forms.Label addEmployeeLabel5;
        private System.Windows.Forms.RadioButton addHourlyRadioButton1;
        private System.Windows.Forms.Label employeeTypesLabel6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label AddSsnLabel5;
        private System.Windows.Forms.Label AddLastNameLabel5;
        private System.Windows.Forms.TextBox addLastNameTextBox1;
        private System.Windows.Forms.Label adFirstNamelabel5;
        private System.Windows.Forms.TextBox addFirstNametextBox1;
        private System.Windows.Forms.GroupBox addComissiongroupBox2;
        private System.Windows.Forms.RadioButton baseComRadioButton2;
        private System.Windows.Forms.Label adSalesLabel6;
        private System.Windows.Forms.Label addComissionLabel7;
        private System.Windows.Forms.TextBox addComissionTextBox1;
        private System.Windows.Forms.TextBox addSalesTextBox2;
        private System.Windows.Forms.RadioButton addComissionRadioButton1;
        private System.Windows.Forms.Label AddHours;
        private System.Windows.Forms.Label Rate;
        private System.Windows.Forms.TextBox addHourRateTextBox2;
        private System.Windows.Forms.TextBox addHoursTextBox1;
        private System.Windows.Forms.Label addSalariedLabel6;
        private System.Windows.Forms.TextBox addSalariedTextBox1;
        private System.Windows.Forms.RadioButton addSalariedRadioButton1;
        private System.Windows.Forms.Button addEmployeebutton1;
        //private System.Windows.Forms.ToolTip toolTip1;
        private ColumnHeader ssnColumnHeader1;
        private ColumnHeader ssnColumnHeader2;
        private ColumnHeader ssnColumnHeader3;
        private ListView EmployeeListView1;
        private ColumnHeader columnHeader1;
        private ListView c;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private ColumnHeader columnHeader6;
        private ColumnHeader ssnColumnHeader4;
        private ColumnHeader columnHeader7;
        private GroupBox sortGroupBox1;
        private Button sortButton1;
        private RadioButton payDesRadioButton4;
        private RadioButton payAscRadioButton3;
        private RadioButton sortLnRadioButton2;
        private RadioButton sortBySsnRadioButton1;
        private ToolTip toolTip2;
        private Label label6;
        private TextBox addBaseTextBox1;
        private MaskedTextBox maskedTextBox1;
        private ToolTip toolTip1;
        private TabPage tabPage4;
        private GroupBox PayInfoGroupBox1;
        private RadioButton allPayRadioButton1;
        private Button displayPayButton1;
        private RadioButton BaseComPayRadioButton1;
        private RadioButton ComisPayRadioButton3;
        private RadioButton hourPayRadioButton4;
        private RadioButton salaryPayInforadioButton5;
        private Button button2;
        private Button button3;
        private Label label7;
        private ListView payListView1;
        private ColumnHeader columnHeader2;
        private MenuStrip menuStrip3;
        private ToolStripMenuItem optionsToolStripMenuItem;
        private ToolStripMenuItem printPreviewToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private PictureBox pictureBox1;
        private Label label8;
        private Label label9;
    }
}