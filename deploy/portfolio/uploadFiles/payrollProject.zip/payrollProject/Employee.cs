﻿//CECS 475
//Jesus Contreras
using System;
using System.Collections.Generic;
namespace PayrollSystem
{
    public abstract class Employee : IPayable, IComparable<Employee>//,// IComparer<Employee>
    {
        // read-only property that gets employee's first name
        public string FirstName { get; private set; }

        // read-only property that gets employee's last name
        public string LastName { get; private set; }

        // read-only property that gets employee's social security number
        public string SocialSecurityNumber { get; private set; }

        // three-parameter constructor
        public Employee(string first, string last, string ssn)
        {
            FirstName = first;
            LastName = last;
            SocialSecurityNumber = ssn;
        } // end three-parameter Employee constructor

        // return string representation of Employee object
        public override string ToString()
        {
            return string.Format("{0} {1}\nsocial security number: {2}",
               FirstName, LastName, SocialSecurityNumber);
        } // end method ToString

        //Implement IComparable CompareTo to provide default sort in ascending order
        public int CompareTo(Employee other)
        {

            if (this.LastName.Equals(other.LastName))//If the lastNames are the same
                return String.Compare(this.FirstName, other.FirstName);//Sort in asc by firstName  // return String.Compare(this.LastName, other.LastName);//sort in asc by ast name

            return String.Compare(this.LastName, other.LastName);
        }
        // Note: We do not implement IPayable method GetPaymentAmount here so
        // this class must be declared abstract to avoid a compilation error.
        public abstract decimal GetPaymentAmount();

        //Since Compare is already overwritten we must implement a different sorting method, using Icomparer 
        //in other sorting private classes will be enable to provide different sorting mechanism using the same logic/class but 
        //simply changing the method signatures.......yupp.

        //Sort the salary in Ascending order.
        private class SortSalaryAsc : IComparer<Employee>
        {
            public int Compare(Employee a, Employee b)
            {
                return (int)a.GetPaymentAmount() - ((int)b.GetPaymentAmount());
            }//end comare
        }//end private class

        //static method allows a method to call private classes without explicit instantiation (static methods cannot be instantiated).
        public static IComparer<Employee> sortSalaryAsc()
        {
            return (IComparer<Employee>)new SortSalaryAsc();
        }

        //Sort the salary in Descending order.
        private class SortSalaryDesc : IComparer<Employee>
        {
            public int Compare(Employee a, Employee b)
            {
                return (int)b.GetPaymentAmount() - (int)a.GetPaymentAmount();
            }//end comare
        }//end private class
        public static IComparer<Employee> sortSalaryDesc()
        {
            return (IComparer<Employee>)new SortSalaryDesc();
        }

        //Sort social security in Ascen. order.
        private class SortSocSec1 : IComparer<Employee>
        {
            public int Compare(Employee a, Employee b)
            {
                return String.Compare(a.SocialSecurityNumber, b.SocialSecurityNumber);
            }//end comare
        }//end private class


        public static IComparer<Employee> SortSocSec()
        {
            return (IComparer<Employee>)new SortSocSec1();
        }
    } // end abstract class Employee

}//End namespace