﻿//Jesus Contreras
//Print class, will allow document (employee data) to be previewed and printed.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data; 
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;


namespace PayrollSystem
{
    class Print
    {
    private PrintPreviewDialog printPreviewDialog1 = new PrintPreviewDialog();
        private PrintDocument printDocument1 = new PrintDocument();

        // Declare a string to hold the entire document contents. 
        private string documentContents;
        private string theTitle;

        // Declare a variable to hold the portion of the document that 
        // is not printed. 
        private string stringToPrint;

        public Print(string theTitle, string theDoc)
        {
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            this.theTitle = theTitle;
            documentContents = theDoc;
        }

        public void execute()
        {
            ReadDocument();
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void ReadDocument()
        {
            string docName = " Print Preview " + theTitle;
            printDocument1.DocumentName = docName;
            stringToPrint = documentContents;
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            int charactersOnPage = 0;
            int linesPerPage = 0;

            //Will set the bounds for the characted to be printed to the cahracters that will be fittble to the page
            e.Graphics.MeasureString(stringToPrint, PayableInterfaceTest.TheForm.Font,
                e.MarginBounds.Size, StringFormat.GenericTypographic,
                out charactersOnPage, out linesPerPage);

            // Will display the information on page
            e.Graphics.DrawString(stringToPrint, PayableInterfaceTest.TheForm.Font, Brushes.Black,
            e.MarginBounds, StringFormat.GenericTypographic);

            // Remove the portion of the string that has been printed.
            stringToPrint = stringToPrint.Substring(charactersOnPage);

            // Check to see if more pages are to be printed.
            e.HasMorePages = (stringToPrint.Length > 0);

            // If there are no more pages, reset the string to be printed. 
            if (!e.HasMorePages)
                stringToPrint = documentContents;
        }

    }
}
