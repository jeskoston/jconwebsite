﻿//Jesus Contreras
//Salaried employee class, has all the attributes you'd expect from a salaried employee.

using System;

namespace PayrollSystem
{

    public class SalariedEmployee : Employee
    {
        private decimal weeklySalary;

        // four-parameter constructor
        public SalariedEmployee(string first, string last, string ssn,
           decimal salary)
            : base(first, last, ssn)
        {
            WeeklySalary = salary; // validate salary via property
        } // end four-parameter SalariedEmployee constructor

        // property that gets and sets salaried employee's salary
        public decimal WeeklySalary
        {
            get
            {
                return weeklySalary;
            } // end get
            set
            {
                if (value >= 0) // validation
                    weeklySalary = value;
                else
                    throw new ArgumentOutOfRangeException("WeeklySalary",
                       value, "WeeklySalary must be >= 0");
            } // end set
        } // end property WeeklySalary

        // calculate earnings; implement interface IPayable method
        // that was abstract in base class Employee
        public override decimal GetPaymentAmount()
        {
            return WeeklySalary;
        } // end method GetPaymentAmount          

        // return string representation of SalariedEmployee object
        public override string ToString()
        {
            return string.Format("\nsalaried employee: {0}\n{1}: {2:C}\n{3}: {4}.00",
                base.ToString(), "weekly salary", WeeklySalary, "Total Pay", GetPaymentAmount());
        } // end method ToString
    } // end class SalariedEmployee
}//End namespace
