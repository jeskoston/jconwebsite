﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//main for payroll system, nothing much to see here.
namespace PayrollSystem
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
} 
