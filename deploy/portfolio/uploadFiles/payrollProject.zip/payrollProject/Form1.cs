﻿//Jesus Contreras
//Alot of the function logic is within the Form1.cs page, alot of the design logic as well. 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;


namespace PayrollSystem
{
    public partial class Form1 : Form
    {


        //Variables for the addition of employees
        string addFirstName, addLastName, addSsn, hoursWorked, hourlyRate, comission, sales, salary, basepay = null;
        decimal hoursworked1, hourlyrate1, comission1, sales1, salary1, basepay1 = 0;
        //The default list of employees
        List<Employee> loadEmployees = loadDefaultList();


        public Form1()
        {
            InitializeComponent();

        }


        private void Form1_Load(object sender, EventArgs e)
        {
            //Messagebox to describe how to use the appliaction
            MessageBox.Show("Payroll System\nIn order to search for an employee in the system please use the first tab\n"
            + "In order to View Employee information please use the second tab\nIn order Add an Employee please use thrid tab\nIn order to generate the payment information for employees please use the fourth tab ");
            //For mask TextBox
            ToolTip toolTip2 = new ToolTip();
            toolTip2.SetToolTip(this.ssnSearchTextBox1, "Please Enter Social Security Number");
            ssnSearchTextBox1.Mask = "000-00-0000";
            ssnSearchTextBox1.MaskInputRejected += new MaskInputRejectedEventHandler(ssnSearchTextBox1_MaskInputRejected);
            ssnSearchTextBox1.KeyDown += new KeyEventHandler(ssnSearchTextBox1_KeyDown);
            //End maskTExtBox
            //Load the default list of employees to the database.
            loadEmployeeInfoList();
            //End load default list
            ToolTip toolTip1 = new ToolTip();
            maskedTextBox1.Mask = "000-00-0000";
            ssnSearchTextBox1.MaskInputRejected += new MaskInputRejectedEventHandler(maskedTextBox1_MaskInputRejected);
            ssnSearchTextBox1.KeyDown += new KeyEventHandler(maskedTextBox1_KeyDown);


        }



        //Will load the First and last name of the employees in the list to the Info List on the secon tab
        private void loadEmployeeInfoList()
        {
            foreach (var element in loadEmployees)
            {
                // var element1 = new theEmployees;
                var myItem = new ListViewItem(new[] { element.FirstName + " " + element.LastName });
                EmployeeListView1.Items.Add(myItem);
            }
        }

        /// <summary>
        //This will dynamically add the default items to the current listview
        private static List<Employee> loadDefaultList()
        {
            //Get the List of Employees in the Text Class
            Employee[] defaultEmployees = new Employee[8];
            // populate array with objects that implement IPayable
            defaultEmployees[0] = new SalariedEmployee("John", "Smith", "111-11-1111", 700M);
            defaultEmployees[1] = new SalariedEmployee("Antonio", "Smith", "555-55-5555", 800M);
            defaultEmployees[2] = new SalariedEmployee("Victor", "Smith", "444-44-4444", 600M);
            defaultEmployees[3] = new HourlyEmployee("Karen", "Price", "222-22-2222", 16.75M, 40M);
            defaultEmployees[4] = new HourlyEmployee("Ruben", "Zamora", "666-66-6666", 20.00M, 40M);
            defaultEmployees[5] = new CommissionEmployee("Sue", "Jones", "333-33-3333", 10000M, .06M);
            defaultEmployees[6] = new BasePlusCommissionEmployee("Bob", "Lewis", "777-77-7777", 5000M, .04M, 300M);
            defaultEmployees[7] = new BasePlusCommissionEmployee("Lee", "Duarte", "888-88-8888", 5000M, .04M, 300M);
            int listLength = defaultEmployees.Length;

            //Now crate a list of Employee Type
            List<Employee> theEmployees = new List<Employee>();
            //Create a list for IPayable objects, populate this this
            foreach (var element in defaultEmployees)
            {
                theEmployees.Add(element);//add payableObjects elements to list

            }
            return theEmployees;
        }//End load default list



        private void CloseButton1_Click(object sender, EventArgs e)
        {
            Close();// will close the application.

        }

        //Will process Social Security info and Look through Empolyees via ssn, will return the employee if in "database"
        private void ssnSearchbutton1_Click(object sender, EventArgs e)
        {

            this.ssnSearchView1.Items.Clear();


            //Get user input for social Security Number
            string searchSsn = "";//The string will be empty from the getgo
            try
            {
                searchSsn = this.ssnSearchTextBox1.Text;//Will assign the value in the textbox as ssn
            }
            catch (FormatException)
            {
                MessageBox.Show("You typed an invalid value\n" +
                    "Please try again");
                this.ssnSearchTextBox1.Focus();
            }

            //conditions defined by the specified predicate, and returns the 
            //first occurrence within the entire <Employee> list
            //Will find and return the inputted social security number
            Employee result = loadEmployees.Find(delegate(Employee emp)
                {

                    return emp.SocialSecurityNumber == searchSsn;
                }
            );
            //display onto textview///////////////////
            if (result != null)
            {

                decimal value = result.GetPaymentAmount();
                string specifier = "C";
                var myItem = new ListViewItem(new[] { result.FirstName, result.LastName, result.SocialSecurityNumber, value.ToString(specifier) });
                ssnSearchView1.Items.Add(myItem);
            }
            //If no social sn is found then then a message will inform the user in the seaerchview
            else
            {
                ssnSearchView1.Items.Add("This person is not in the DB");

            }

        }
        //Tooltip for the social security search bix, will let the user know when they input too many numbers,
        //Characters, or nothing at all
        private void ssnSearchTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (ssnSearchTextBox1.MaskFull)
            {
                toolTip2.ToolTipTitle = "Input Rejected - Too Much Data";
                toolTip2.Show("You cannot enter any more data into the SSN field. Delete some characters in order to insert more data.", ssnSearchTextBox1, 0, -20, 2500);
            }
            else if (e.Position == ssnSearchTextBox1.Mask.Length)
            {
                toolTip2.ToolTipTitle = "Input Rejected - End of Field";
                toolTip2.Show("You cannot add extra characters to the end of this SSN field.", ssnSearchTextBox1, 0, -20, 2500);
            }
            else
            {

                toolTip2.ToolTipTitle = "Input Rejected";
                toolTip2.Show("You can only add numeric characters into this SSN field.", ssnSearchTextBox1, 0, -20, 2500);
            }
        }

        // The balloon tip is visible for five seconds; if the user types any data before it disappears, collapse it ourselves.
        void ssnSearchTextBox1_KeyDown(object sender, KeyEventArgs e)
        {

            toolTip2.Hide(ssnSearchTextBox1);
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }



        private void ssnSearchView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CheckKeys(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                ssnSearchbutton1_Click(sender, e);
            }
        }

        private void employeeNameListView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {



        }

        private void EmployeeListView1_ItemActivate(object sender, EventArgs e)
        {

            //Clears item in listview
            c.Items.Clear();
            //Searches through employees for first an last name will return an employee if available
            Employee result = loadEmployees.Find(delegate(Employee emp)
            {

                return emp.FirstName + " " + emp.LastName == EmployeeListView1.SelectedItems[0].Text;
            }
           );
            //display onto textview///////////////////
            if (result != null)
            {

                decimal value = result.GetPaymentAmount();
                string specifier = "C";
                var myItem = new ListViewItem(new[] { result.FirstName, result.LastName, result.SocialSecurityNumber, value.ToString(specifier) });
                c.Items.Add(myItem);

            }
            else
            {
                MessageBox.Show("This person is not in the payroll database");//E.Items.Add("his person is not in the DB");
                //Console.WriteLine("\nNot found: {0}", searchSsn);
            }
        }

        private void EmployeeInfoListView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void sortBySsnRadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void sortLnRadioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void payAscRadioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void payDesRadioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }


        private void sortButton1_Click(object sender, EventArgs e)
        {
            //Sort by SSN if radio button chosen
            if (sortBySsnRadioButton1.Checked)
            {
                sortSsnAndPrint();
            }
            //Sort by Last Name if radio button chosen
            else if (sortLnRadioButton2.Checked)
            {
                sortLastNameAndPrint();
            }
            //Sort by Ascending pay if radio button chosen
            else if (payAscRadioButton3.Checked)
            {
                sortAscendPayAndPrint();
            }
            //Sort by Descending pay if radio button chosen
            else if (payDesRadioButton4.Checked)
            {
                sortDescendPayAndPrint();
            }
            //Otherwise show an error
            else
            {
                MessageBox.Show("To sort please select a way to sort the Employee info");
            }
        }


        private void closeButton2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void sortGroupBox1_Enter(object sender, EventArgs e)
        {

        }
        //Sorts Employees in list based off their SSN 
        private void sortSsnAndPrint()
        {
            c.Items.Clear();
            int sizeOfList = loadEmployees.Count;
            loadEmployees.Sort(Employee.SortSocSec());
            for (int i = 0; i < sizeOfList; i++)
            {
                var item = loadEmployees.ElementAt(i);
                decimal value = item.GetPaymentAmount();
                string specifier = "C";
                var myItem = new ListViewItem(new[] { item.FirstName, item.LastName, item.SocialSecurityNumber, value.ToString(specifier) });
                c.Items.Add(myItem);
            }
        }
        //Sorts Employees in list based off their Last Name
        private void sortLastNameAndPrint()
        {
            c.Items.Clear();
            int sizeOfList = loadEmployees.Count;
            loadEmployees.Sort();
            for (int i = 0; i < sizeOfList; i++)
            {
                var item = loadEmployees.ElementAt(i);
                decimal value = item.GetPaymentAmount();
                string specifier = "C";
                var myItem = new ListViewItem(new[] { item.FirstName, item.LastName, item.SocialSecurityNumber, value.ToString(specifier) });
                c.Items.Add(myItem);
            }
        }
        //Sorts Employees in list based off their Pay in Ascending order
        private void sortAscendPayAndPrint()
        {

            c.Items.Clear();
            int sizeOfList = loadEmployees.Count;
            loadEmployees.Sort(Employee.sortSalaryAsc());
            for (int i = 0; i < sizeOfList; i++)
            {
                var item = loadEmployees.ElementAt(i);
                decimal value = item.GetPaymentAmount();
                string specifier = "C";
                var myItem = new ListViewItem(new[] { item.FirstName, item.LastName, item.SocialSecurityNumber, value.ToString(specifier) });
                c.Items.Add(myItem);
            }
        }
        //Sorts Employees in list based off their Pay in Descending order
        private void sortDescendPayAndPrint()
        {
            c.Items.Clear();
            int sizeOfList = loadEmployees.Count;
            loadEmployees.Sort(Employee.sortSalaryDesc());
            for (int i = 0; i < sizeOfList; i++)
            {
                var item = loadEmployees.ElementAt(i);
                decimal value = item.GetPaymentAmount();
                string specifier = "C";
                var myItem = new ListViewItem(new[] { item.FirstName, item.LastName, item.SocialSecurityNumber, value.ToString(specifier) });
                c.Items.Add(myItem);
            }
        }

        private void addFirstNametextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void addLastNameTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void addSsnTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

       
        //If add hourly Employee is checked then disable irrelevant textboxes
        private void addHourlyRadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //addHourlyRadioButton1.Enabled = true;
            if (addHourlyRadioButton1.Checked == true)
            { 
                addHoursTextBox1.Enabled = true;
                addBaseTextBox1.Enabled = false;
                addBaseTextBox1.Enabled = false;
                addSalariedTextBox1.Enabled = false;
                addHourRateTextBox2.Enabled = true;
                addSalariedTextBox1.Enabled = false;
                addBaseTextBox1.Enabled = false;
                addComissionTextBox1.Enabled = false;
                addSalesTextBox2.Enabled = false;
            }
        
        }

        private void addHourRateTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void addHoursTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //If add commission is checked then disable irrelevant textboxes
        private void addComissionRadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (addComissionRadioButton1.Checked == true)
            {
                addBaseTextBox1.Enabled = false;
                addSalariedTextBox1.Enabled = false;
                addHourRateTextBox2.Enabled = false;
                addHoursTextBox1.Enabled = false;
                addSalariedTextBox1.Enabled = false;
                addSalesTextBox2.Enabled = true;
                addComissionTextBox1.Enabled = true;
            }
        }
        //If add base commission is checked then disable irrelevant textboxes
        private void baseComRadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (!baseComRadioButton2.Checked == true)
            {
                
                addBaseTextBox1.Enabled = false;
            }
            else if (baseComRadioButton2.Checked == true)
            {
                addBaseTextBox1.Enabled = true;
                addSalariedTextBox1.Enabled = false;
                addHourRateTextBox2.Enabled = false;
                addHoursTextBox1.Enabled = false;
                addSalariedTextBox1.Enabled = false;
                addSalesTextBox2.Enabled = true;
                addComissionTextBox1.Enabled = true;

            }

        }


        private void addComissionTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void addSalesTextBox2_TextChanged(object sender, EventArgs e)
        {

        }


        private void addSalariedTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //If add addSalaried is checked then disable irrelevant textboxes
        private void addSalariedRadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (addSalariedRadioButton1.Checked == true)
            {
                
                addBaseTextBox1.Enabled = false;
                addHourRateTextBox2.Enabled = false;
                addHoursTextBox1.Enabled = false;
                addSalariedTextBox1.Enabled = true;
                addSalesTextBox2.Enabled = false;
                addComissionTextBox1.Enabled = false;
            }
        }


        //Once the User fills in employee data, AddEmployeeButton1_Click willl process all the information
        private void addEmployeebutton1_Click(object sender, EventArgs e)
        {

            //-----Unique Employee Data
            try
            {
                addFirstName = this.addFirstNametextBox1.Text;//Will assign the value in the textbox as firstName

            }
            catch (FormatException)
            {
                MessageBox.Show("You typed an invalid First Name value\n" +
                   "Please try again");
                this.addFirstNametextBox1.Focus();
            }

            try
            {
                addLastName = this.addLastNameTextBox1.Text;//Will assign the value in the textbox as lastName
            }
            catch (FormatException)
            {
                MessageBox.Show("You typed an invalid Last Name value\n" +
                    "Please try again");
                this.addLastNameTextBox1.Focus();
            }

            try
            {
                addSsn = this.maskedTextBox1.Text;//Will assign the value in the textbox as firstName
            }
            catch (FormatException)
            {
                MessageBox.Show("You typed an invalid Social Security value\n" +
                    "Please try again");
                this.maskedTextBox1.Focus();
            }

            //-----Hourly Employee-----
            if (addHourlyRadioButton1.Checked)
            {

                try
                {
                    hourlyRate = this.addHourRateTextBox2.Text;//Will assign the value in the textbox as hourly rate
                    hourlyrate1 = Convert.ToDecimal(hourlyRate);
                }
                catch (FormatException)
                {
                    MessageBox.Show("You typed an invalid hourly rate value\n" +
                        "Please try again");
                    this.addHourRateTextBox2.Focus();
                }

                try
                {

                    hoursWorked = this.addHoursTextBox1.Text;//Will assign the value in the textbox as firstName
                    hoursworked1 = Convert.ToDecimal(hoursWorked);
                }
                catch (FormatException)
                {
                    MessageBox.Show("You typed an invalid Last Name value\n" +
                        "Please try again");
                    this.addHoursTextBox1.Focus();
                }//End catch
                Employee addEmployee = new HourlyEmployee(addFirstName, addLastName, addSsn, hourlyrate1, hoursworked1);
                loadEmployees.Add(addEmployee);
                decimal value = addEmployee.GetPaymentAmount();
                string specifier = "C";
                var myItem = new ListViewItem(new[] { addEmployee.FirstName, addEmployee.LastName, addEmployee.SocialSecurityNumber, value.ToString(specifier) });
                EmployeeListView1.Items.Add(addEmployee.FirstName + " " + addEmployee.LastName);
                MessageBox.Show("You successfully a Hourly Employee");

            }//End if hourlyEmployee

            //-----ComissionedEmployee-
            else if (addComissionRadioButton1.Checked)
            {

                try
                {
                    comission = this.addComissionTextBox1.Text;//Will assign the value in the textbox as hourly rate
                    comission1 = Convert.ToDecimal(comission);
                }
                catch (FormatException)
                {
                    MessageBox.Show("You typed an invalid comission value\n" +
                        "Please try again");
                    this.addComissionTextBox1.Focus();
                }

                try
                {
                    sales = this.addSalesTextBox2.Text;
                    sales1 = Convert.ToDecimal(sales);
                }
                catch (FormatException)
                {
                    MessageBox.Show("You typed an invalid Last Name value\n" +
                        "Please try again");
                    this.addSalesTextBox2.Focus();
                }//End catch
                Employee addEmployee = new CommissionEmployee(addFirstName, addLastName, addSsn, sales1, comission1);
                loadEmployees.Add(addEmployee);
                decimal value = addEmployee.GetPaymentAmount();
                string specifier = "C";
                var myItem = new ListViewItem(new[] { addEmployee.FirstName, addEmployee.LastName, addEmployee.SocialSecurityNumber, value.ToString(specifier) });
                EmployeeListView1.Items.Add(addEmployee.FirstName + " " + addEmployee.LastName);
                MessageBox.Show("You successfully a Commission Employee");
            }//End if Comission Employee
            
                //Base plus Comission Employee
            else if (baseComRadioButton2.Checked)
            {

                try
                {
                    comission = this.addComissionTextBox1.Text;//Will assign the value in the textbox as hourly rate
                    comission1 = Convert.ToDecimal(comission);
                }
                catch (FormatException)
                {
                    MessageBox.Show("You typed an invalid comission value\n" +
                        "Please try again");
                    this.addComissionTextBox1.Focus();
                }

                try
                {
                    sales = this.addSalesTextBox2.Text;
                    sales1 = Convert.ToDecimal(sales);
                }
                catch (FormatException)
                {
                    MessageBox.Show("You typed an invalid sales value\n" +
                        "Please try again");
                    this.addSalesTextBox2.Focus();
                }//End catch
                try
                {
                    basepay = this.addBaseTextBox1.Text;
                    basepay1 = Convert.ToDecimal(basepay);
                }
                catch (FormatException)
                {
                    MessageBox.Show("You typed an invalid Base pay value\n" +
                        "Please try again");
                    this.addBaseTextBox1.Focus();
                }//End Add Base plus comission
                Employee addEmployee = new BasePlusCommissionEmployee(addFirstName, addLastName, addSsn, sales1, comission1, basepay1);
                loadEmployees.Add(addEmployee);
                decimal value = addEmployee.GetPaymentAmount();
                string specifier = "C";
                var myItem = new ListViewItem(new[] { addEmployee.FirstName, addEmployee.LastName, addEmployee.SocialSecurityNumber, value.ToString(specifier) });
                EmployeeListView1.Items.Add(addEmployee.FirstName + " " + addEmployee.LastName);
                MessageBox.Show("You successfully a Base + Commission Employee");
            }

            else if (addSalariedRadioButton1.Checked)
            {

                try
                {
                    salary = this.addSalariedTextBox1.Text;//Will assign the value in the textbox as hourly rate
                    salary1 = Convert.ToDecimal(salary);
                }
                catch (FormatException)
                {
                    MessageBox.Show("You typed an invalid Salary value\n" +
                        "Please try again");
                    this.addSalariedTextBox1.Focus();
                }
                Employee addEmployee = new SalariedEmployee(addFirstName, addLastName, addSsn, salary1);
                loadEmployees.Add(addEmployee);
                decimal value = addEmployee.GetPaymentAmount();
                string specifier = "C";
                var myItem = new ListViewItem(new[] { addEmployee.FirstName, addEmployee.LastName, addEmployee.SocialSecurityNumber, value.ToString(specifier) });
                EmployeeListView1.Items.Add(addEmployee.FirstName + " " + addEmployee.LastName);
                MessageBox.Show("You successfully a Salary Employee");
            }


            else
            {
                MessageBox.Show("Please make a selection of Employee type to add");
            }


        }// end add Employee


        private void generalInfoGroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void toolTip2_Popup(object sender, PopupEventArgs e)
        {
        }

        private void addSalariedGroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        //Tooltip for social security in Add Employee
        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (maskedTextBox1.MaskFull)
            {
                toolTip1.ToolTipTitle = "Input Rejected - Too Much Data";
                toolTip1.Show("You cannot enter any more data into the social security number field. Delete some characters in order to insert more data.", maskedTextBox1, 0, -20, 2500);
            }
            else if (e.Position == maskedTextBox1.Mask.Length)
            {
                toolTip1.ToolTipTitle = "Input Rejected - End of Field";
                toolTip1.Show("You cannot add extra characters to the end of this social security number field.", maskedTextBox1, 0, -20, 2500);
            }
            else
            {

                toolTip1.ToolTipTitle = "Input Rejected";
                toolTip1.Show("You can only add numeric characters into this social security number field.", maskedTextBox1, 0, -20, 2500);
            }
        }

        void maskedTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            // The balloon tip is visible for five seconds; if the user types any data before it disappears, collapse it ourselves.

            toolTip1.Hide(maskedTextBox1);
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void displayPayButton1_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void displayPayButton1_Click_1(object sender, EventArgs e)
        {
            //If the Salary Radio button selected, display pay for all salary employees
            if (salaryPayInforadioButton5.Checked)
            {
                showSalaryPay();
            }
            //If the Hourly Radio button selected, display pay for all hourly employees
            else if (hourPayRadioButton4.Checked)
            {
                showHourlyPay();
            }
            //If the Commission Radio button selected, display pay for all commission employees
            else if (ComisPayRadioButton3.Checked)
            {
                showCommissPay();
            }
            //If the Base+Commission Radio button selected, display pay for all BPC employees
            else if (BaseComPayRadioButton1.Checked)
            {
                basePlusCommisPay();
            }
            //If the All Radio button selected, display pay for all employees
            else if (allPayRadioButton1.Checked)
            {
                showAllPay();
            }
            else
            {
                MessageBox.Show("To calculate and display payment information please select an option");
            }
        }

        private void BaseComPayRadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
        //Calculates and displays the payment information for all salaried employees
        private void showSalaryPay()
        {
            payListView1.Items.Clear();
            string specifier;
            specifier = "C";
            int i = 0;
            decimal tempValue;
            decimal value = 0;
            int sizeOfList = loadEmployees.Count;
            while (i < sizeOfList)
            {
                var item = loadEmployees.ElementAt(i);
                tempValue = item.GetPaymentAmount();
                // If an item is of type Salaried Employee, add up the value of their payments 
                if (item is SalariedEmployee)
                {
                    value = value + tempValue;// add the value of previous employee to that of another employee of the same type
                }
                i++;//increment the value of the array which hold the employees (move on to the next employee)
            }
            var myItem = new ListViewItem(new[] { "Total Payroll Due to Salary Employees : " + value.ToString(specifier) });
            payListView1.Items.Add(myItem);
        }
        //Calculates and displays the payment information for all hourly employees
        private void showHourlyPay()
        {
            payListView1.Items.Clear();
            string specifier;
            specifier = "C";
            int i = 0;
            decimal tempValue;
            decimal value = 0;
            int sizeOfList = loadEmployees.Count;
            while (i < sizeOfList)
            {
                var item = loadEmployees.ElementAt(i);
                tempValue = item.GetPaymentAmount();
                // If an item is of type hourly Employee, add up the value of their payments
                if (item is HourlyEmployee)
                {
                    value = value + tempValue;// add the value of previous employee to that of another employee of the same type
                }
                i++;
            }
            var myItem = new ListViewItem(new[] { "Total Payroll Due to Hourly Employees : " + value.ToString(specifier) });
            payListView1.Items.Add(myItem);
        }
        //Calculates and displays the payment information for all commission employees
        private void showCommissPay()
        {
            payListView1.Items.Clear();
            string specifier;
            specifier = "C";
            int i = 0;
            decimal tempValue;
            decimal value = 0;
            int sizeOfList = loadEmployees.Count;
            while (i < sizeOfList)
            {
                var item = loadEmployees.ElementAt(i);
                tempValue = item.GetPaymentAmount();
                // If an item is of type Commission Employee, add up the value of their payments
                if (item is CommissionEmployee)
                {
                    value = value + tempValue;// add the value of previous employee to that of another employee of the same type
                }
                i++;
            }
            var myItem = new ListViewItem(new[] { "Total Commission Due to Salary Employees : " + value.ToString(specifier) });
            payListView1.Items.Add(myItem);
        }
        //Calculates and displays the payment information for all BPC employees
        private void basePlusCommisPay()
        {
            payListView1.Items.Clear();
            string specifier;
            specifier = "C";
            int i = 0;
            decimal tempValue;
            decimal value = 0;
            int sizeOfList = loadEmployees.Count;
            while (i < sizeOfList)
            {
                var item = loadEmployees.ElementAt(i);
                tempValue = item.GetPaymentAmount();
                // If an item is of type BPC Employee, add up the value of their payments
                if (item is BasePlusCommissionEmployee)
                {
                    value = value + tempValue;// add the value of previous employee to that of another employee of the same type
                }
                i++;
            }
            var myItem = new ListViewItem(new[] { "Total Payroll Due to Base Commission Employees : " + value.ToString(specifier) });
            payListView1.Items.Add(myItem);
        }
        //Calculates and displays the payment information for all  employees
        private void showAllPay()
        {
            payListView1.Items.Clear();
            string specifier;
            specifier = "C";
            int i = 0;
            decimal tempValue;
            decimal value = 0;
            int sizeOfList = loadEmployees.Count;
            while (i < sizeOfList)
            {
                var item = loadEmployees.ElementAt(i);
                tempValue = item.GetPaymentAmount();
                value = value + tempValue;
                i++;
            }
            var myItem = new ListViewItem(new[] { "Total Payroll Due to All Employees : " + value.ToString(specifier) });
            payListView1.Items.Add(myItem);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        //If the printPreview menuStrip option is selected then gather up all the employee information and send to Print class so it can be formatted into proper print preview format for display
        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string theTitle = "";
            string allEmps = "";

            allEmps = "**********Employee Information**********\n\nFull Name        SSN               Pay Amount\n\n" + loadEmployeesToPrint();
            Print preview = new Print(theTitle, allEmps);
            preview.execute();

        }
        //Will load all the unique information of all of the employees, loadEmployeesToPrint() prepares the employee informaton
        //to be printed it returns First Name, Last Name , SSN, and Pay of each employee, those values will be accessed
        //within printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        private string loadEmployeesToPrint()
        {

            int sizeOfList = loadEmployees.Count;
            loadEmployees.Sort(Employee.SortSocSec());
            string printEmps = "";
            for (int i = 0; i < sizeOfList; i++)
            {
                var item = loadEmployees.ElementAt(i);
                decimal value = item.GetPaymentAmount();
                string specifier = "C";
                printEmps += item.FirstName + " " + item.LastName + "     " + item.SocialSecurityNumber + "     " + value.ToString(specifier) + "\n\n";

            }
            return printEmps;

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void addComissiongroupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }//End class
}//End namespace


