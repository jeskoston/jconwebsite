﻿//CECS 475 
//Jesus Contreras

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections.ObjectModel;

namespace PayrollSystem
{
    public class PayableInterfaceTest
    {
        public static void Main(string[] args)
        {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //TheEmployees = new EmployeeCollection();
            TheForm = new Form1();

            Application.Run(TheForm);

        } // end Main
        public static Form1 TheForm { get; private set; }
    } // end class PayableInterfaceTest

}//End of namespace
