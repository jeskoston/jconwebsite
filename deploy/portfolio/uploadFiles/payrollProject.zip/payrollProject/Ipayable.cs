﻿//Jesus Contreras
//Ipayable interface in charge of getting payment amount.

namespace PayrollSystem
{
    public interface IPayable
    {
        decimal GetPaymentAmount(); // calculate payment; no implementation
    } // end interface IPayable

}