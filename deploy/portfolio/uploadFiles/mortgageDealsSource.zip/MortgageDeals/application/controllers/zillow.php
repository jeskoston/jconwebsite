<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Zillow extends CI_Controller {
    
    /*
     * Note to self after connecting to api need to parse xml
     * 
     * 
     */

    public function index() {
       
        /*
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->view('view_home');
        */
        
        // loan amount, downpayment percent, rate from the bank, length of loan to be repaid
        $this->CalculateMonthlyPaymentsAdvanced('320000', '20', '4.37', '360');
    }

    function send(){
        $this->load->library('form_validation');
        
        //field name, error message,validation ruels
        $this->form_validation->set_rules('price','price', 'required | trim' );
         $this->form_validation->set_rules('down','down', 'required | trim' );
         $this->form_validation->set_rules('zip','zip',  'required | trim ' );
         
         if($this->form_validation->run())
         {
            
             $price1=  $this->input->post('price');
             $down1=  $this->input->post('down');
             $zipcode1=  $this->input->post('zip');
             
             
             
             $this->zillowExample2Monthly($price1, $down1, $zipcode1);
             
         }
         else//did not pass validation
         {
              $this->load->view('home_view');
         }
         
         
    }
    
    //price= 300000
    //down =15
    //zipcode=98104 
    /*Example this method we do not use
     * 
     */
    function zillowExample2Monthly($price, $down, $zipcode) {//$price, $down, $zipcode)
        $handle = curl_init();
        $ourZillowId = 'X1-ZWz1bi4ag3r1u3_88dza';
        //X1-ZWz1bi4ag3r1u3_88dza
        //curl_setopt($handle, CURLOPT_URL => 'http://www.zillow.com/webservice/GetMonthlyPayments.htm');
        curl_setopt_array($handle, array(CURLOPT_URL => 'http://www.zillow.com/webservice/GetMonthlyPayments.htm',
            CURLOPT_POST => false,
            CURLOPT_POSTFIELDS => 'zws-id=' . $ourZillowId . '&price=' . $price . '&down=' . $down . '&zip=' . $zipcode,
            CURLOPT_RETURNTRANSFER => true)
        );
        $response = curl_exec($handle);
        $xml = simplexml_load_string($response, 'SimpleXMLElement', LIBXML_NOCDATA);
        $xm2 = simplexml_load_string($response);

        curl_close($handle);

        // echo '<pre>';
        //print_r($response);


        print_r($xml);
        echo '<br >';

        echo "You request" . "<br >" .
        "-------------------" . "<br >" .
        "The Price you enter is " . $xm2->request->price . "<br >" .
        "The percent downpayment you enter is " . $xm2->request->down . "<br >" .
        "The zip code you enter where you mortage is located " . $xm2->request->zip . "<br ><br >" .
        "You respond" . "<br >" .
        "-------------------" . "<br >" .
        "Your monthly and Interest payment for 30 year type loan is " . $xm2->response->payment[0]->monthlyPrincipalAndInterest . "<br>" .
        "Your monthly and Interest payment for 15 year type loan is " . $xm2->response->payment[1]->monthlyPrincipalAndInterest . "<br>" .
        "Your monthly and Interest payment for NPR year type loan is " . $xm2->response->payment[2]->monthlyPrincipalAndInterest . "<br>"
        ;
        
    }
    
    /*Parameter require else connection crashes
     *    zws-id-is the developer id for zillow
     *    price-price of the house
     *    down-Percent of downpayment of the house coresponds to the price
     *    rate-Is the Interest rate of the loan
     *    terminmonths-months of the loans required
     * 
     * Parameter optional
     *    zip-zipcode for the loan
     *    insurance-
     */
    function CalculateMonthlyPaymentsAdvanced($price, $down,$rate,$terminmonths) {
        
        
        $handle = curl_init();
        $ourZillowId = 'X1-ZWz1bi4ag3r1u3_88dza';//zillow developer id
        $schedule='none';//can switch form monthly,yearly,both,none
   
        curl_setopt_array($handle, array(CURLOPT_URL => 'http://www.zillow.com/webservice/mortgage/CalculateMonthlyPaymentsAdvanced.htm',
            CURLOPT_POST => false,
            /*Might need later for more implementation
            CURLOPT_POSTFIELDS => 'zws-id=' . $ourZillowId . '&price=' . $price . '&down=' . $down .
                                  '&rate='.$rate .'&terminmonths='.$terminmonths. '&schedule='.$schedule.
                                   '&propertytax=2000'.'&hazard=1000'.'&pmi=150'.'&zip=98103'.'&hoa=3200',
            */
              CURLOPT_POSTFIELDS => 'zws-id=' . $ourZillowId . '&price=' . $price . '&down=' . $down .
                                  '&rate='.$rate .'&terminmonths='.$terminmonths. '&schedule='.$schedule,
                                  
            CURLOPT_RETURNTRANSFER => true)
        );
        $response = curl_exec($handle);
        $xml = simplexml_load_string($response, 'SimpleXMLElement', LIBXML_NOCDATA);
        $xm2 = simplexml_load_string($response);

        curl_close($handle);
        
       
        
        $reply=array(
           /*0*/'monthlyprincipalandinterest' =>(string)$xm2->response->monthlyprincipalandinterest,
           /*1*/ 'monthlypropertytaxes' =>(string)$xm2->response->monthlypropertytaxes,
           /*2*/ 'monthlyhazardinsurance' =>(string)$xm2->response->monthlyhazardinsurance,
           /*3*/ 'monthlypmi' =>(string)$xm2->response->monthlypmi,
           /*4*/ 'monthlyhoadues' =>(string)$xm2->response->monthlyhoadues,
           /*5*/ 'totalmonthlypayment' =>(string)$xm2->response->totalmonthlypayment,
           /*6*/ 'totalpayments' =>(string)$xm2->response->totalpayments,
           /*7*/ 'totalinterest' =>(string)$xm2->response->totalinterest,
           /*8*/ 'totalprincipal' =>(string)$xm2->response->totalprincipal,
           /*9*/ 'totaltaxesfeesandinsurance' =>(string)$xm2->response->totaltaxesfeesandinsurance, 
            
            
        );
       
       
        print_r($xml);
        echo '<br >';
        foreach($reply as $content=>$value)
        {
            echo " The ". $content. " is ". $value." <br >";
        }
        return $reply;
       
        
    }
    

}

