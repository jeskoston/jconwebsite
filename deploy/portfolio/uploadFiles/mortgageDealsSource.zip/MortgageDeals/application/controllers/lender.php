<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Lender extends CI_Controller {
	
    function __construct()
    {
        parent::__construct();
        $this->load->library(array('table','form_validation','email'));
        $this->load->helper('url');
        $this->load->model('Lender_model');
        $this->load->library('grocery_CRUD');
    }
    
    public function _admin_output($output = NULL)
    {
        $this->load->view('site_lender/my_account',$output);
    }
    
    public function _new_lead_output($output = NULL)
    {
        $this->load->view('site_lender/leads',$output);
    }
    
    public function _my_lead_output($output = NULL)
    {
        $this->load->view('site_lender/home',$output);
    }
    
    public function display_credit()
    {
        $credit_vailable = $this->Lender_model->get_credit_available($this->session->userdata('username'));
            
        $data = array(
                
            'credit_left' => $credit_vailable->credit_available
        );
        
        $this->session->set_userdata($data);
    }

    public function index()
    {
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {
            $this->display_credit();
            
            $lead = new grocery_CRUD();
            $lender = $this->Lender_model->get_lender_info($this->session->userdata('username'));
            $lender_id = $lender->lender_id;
            $lead->where('lender_id',$lender_id);
            $lead->set_theme('datatables');
            $lead->set_table('tbl_purchase_info');
            
            $lead->columns('email','purchase_price','date_purchase','purchase_by','purchase_status')
                 ->display_as('email','Borrower Email')
                 ->display_as('purchase_price','Price')
                 ->display_as('date_purchase','Date Purchase')
                 ->display_as('purchase_by','Purchase By')
                 ->display_as('purchase_status','Lead Status');
            
            $lead->unset_add();
            $lead->unset_edit();
            $lead->unset_export();
            $lead->unset_print();
            $lead->unset_delete();
            
            $lead->add_action('View','','lender/borrower_detail');
            $lead->add_action('Make Offer','','lender/make_offer');
            $lead->add_action('Update Offer','','lender/update_offer');
            
            $output = $lead->render();
            $this->_my_lead_output($output);  
           //$this->load->view('site_lender/home',$data);
        }
        else $this->load->view('site_lender/login');
    }
    
    public function borrower_detail($purchase_id)
    {
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {  
            $borrwower = $this->Lender_model->get_borrower_info($purchase_id);
            $data['status'] = $borrwower->borrower_status;
            $data['property_usage'] = $borrwower->property_usage;
            $data['property_city'] = $borrwower->city;
            $data['property_state'] = $borrwower->state;
            $data['property_zipcode'] = $borrwower->zipcode;
            $data['loan_amount'] = $borrwower->loan_amount;
            $data['down_percent'] = $borrwower->down_percent;
            $data['credit_rating'] = $borrwower->credit_rating;
            $data['credit_debt'] = $borrwower->credit_debt;
            $data['foreclose'] = $borrwower->foreclosure; 
            $data['full_name'] = $borrwower->first_name." ".$borrwower->last_name;
            $data['address'] = $borrwower->address;
            $data['city'] = $borrwower->city;
            $data['state'] = $borrwower->state_name;
            $data['zipcode'] = $borrwower->zipcode;
            $data['phone'] = $borrwower->phone;
            $data['mobile'] = $borrwower->mobile;
            $data['email'] = $borrwower->email;
            $this->load->view('site_lender/borrower',$data);
        }
        else $this->load->view('site_lender/login');
    }
   
    public function login()
    {
        $data['msg'] = "";
        
        if ($this->Lender_model->authenticate_user($this->input->post('username'),$this->input->post('password')))
        {
            $data = array(
                'username' => $this->input->post('username'),
                'user_type' => 2,
                'lender_logged_in' => TRUE
            );
            $this->session->set_userdata($data);
            redirect('lender');
        }
        else 
        {
            $data['msg'] = "Invalid Username or/and Password";
            $this->load->view('site_lender/login',$data);
        }
        
    }

    public function my_account()
    {
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {
            $this->display_credit();
            $lender = new grocery_CRUD();
            $lender->where('username',$this->session->userdata('username'));
            $lender->set_theme('datatables');
            $lender->set_table('tbl_lender_info');
            $lender->set_subject('My Account');

            $lender->columns('lender_name','lender_address','lender_city','lender_state','lender_zipcode','lender_country')
                   ->display_as('lender_name','Lender')
                   ->display_as('lender_address','Address')
                   ->display_as('lender_city','City')
                   ->display_as('lender_state','State')
                   ->display_as('lender_zipcode','Zipcode')
                   ->display_as('lender_country','Country')
                   ->display_as('lender_phone','Phone')
                   ->display_as('lender_fax','Fax')
                   ->display_as('lender_email','Email');

            //$lender->add_fields('lender_name','lender_address','lender_city','lender_state','lender_zipcode','lender_country','lender_phone','lender_fax','lender_email');
            $lender->edit_fields('lender_name','lender_address','lender_city','lender_state','lender_zipcode','lender_country','lender_phone','lender_fax','lender_email');

            $lender->set_relation('lender_state','tbl_state','state_name');
            $lender->set_relation('lender_country','tbl_country','country_name');
            $lender->required_fields('lender_name');

            $lender->unset_add();
            $lender->unset_export();
            $lender->unset_print();
            $lender->unset_delete();
            
            $lender->add_action('Change Password','','lender/change_password');

            $output = $lender->render();
            $this->_admin_output($output);
        
        }// end authentication if
        else $this->load->view('site_lender/login');
    }

    public function new_lead()
    {
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {
            $this->display_credit();
            $lead = new grocery_CRUD();
            $lead->set_theme('datatables');
            $lead->set_table('tbl_mortgate_profile');
            $lead->where('borrower_status','Open');
            $lead->columns('property_usage','city','state','zipcode','loan_amount','down_percent','credit_rating','foreclosure','credit_debt')
                 ->display_as('property_usage','Property Usage')
                 ->display_as('city','City')
                 ->display_as('state','State')
                 ->display_as('zipcode','Zip Code')
                 ->display_as('loan_amount','Loan Amount')
                 ->display_as('down_percent','Down Percent')
                 ->display_as('credit_rating','Credit Rating')
                 ->display_as('foreclosure','Foreclose')
                 ->display_as('credit_debt','Credit Debt');

            $lead->unset_add();
            $lead->unset_edit();
            $lead->unset_delete();
            $lead->unset_export();
            $lead->unset_print();

            $lead->add_action('Purchase Info','','lender/purchase');

            $output = $lead->render();
            $this->_new_lead_output($output);
        }
        else $this->load->view('site_lender/login');
    }
    
    public function make_offer($purchase_id)
    {
        $data['msg'] = "";
        
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {
            $borrower_info = $this->Lender_model->get_borrower_info($purchase_id);
            $data['full_name'] = $borrower_info->first_name." ".$borrower_info->last_name;
            $data['email'] = $borrower_info->email;
            $borrower = array(
                'full_name' =>$borrower_info->first_name." ".$borrower_info->last_name,
                'email' => $borrower_info->email,
                'purchase_id' => $purchase_id
            );
            $this->session->set_userdata($borrower);
            
            $this->load->view('site_lender/offer',$data);
        }
        else $this->load->view('site_lender/login');
    }
    
    public function save_offer()
    {
        $this->form_validation->set_rules('rate_offer','Rate Offer', 'trim|required|numeric|greater_than[0]|less_than[11]');
        $lender = $this->Lender_model->get_lender_info($this->session->userdata('username'));
        $data['full_name'] = $this->session->userdata('full_name');
        $data['email'] = $this->session->userdata('email');
        
        if ($this->form_validation->run() === FALSE)
        {
            $data['msg'] = "";
        }
        else
        {  
            $data = array(
                'rate_offer' => $this->input->post('rate_offer'),//100
                'borrower_email' => $this->session->userdata('email'),
                'lender_id' => $lender->lender_id,
                'offer_by' => $this->session->userdata('username'),
                'transaction_status' => 'offered'
            );
            
            $this->Lender_model->add_transaction($data);
            $purchase_info = array(
                'purchase_status' => 'offered'
            );
            
            $this->Lender_model->update_purchase_info($this->session->userdata('purchase_id'),$purchase_info);
            
            $lender = $this->Lender_model->get_lender_info($this->session->userdata('username'));
            
            // sending notification email to borrower
            $this->email->from('contact@vietthongtin.com', 'Mortgage Deals');
            $this->email->to($this->session->userdata('email'));
            $this->email->subject('Mortgage Offer');
            $this->email->message('Lender : '.$lender->lender_name. 'has offered you a mortgage rate.');

            $this->email->send();
            
            redirect('lender');
        }
        
        $this->load->view('site_lender/offer',$data);
    }
    
    public function purchase($mortgage_id)
    {
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {
            $data['msg'] = "";
            $lender = $this->Lender_model->get_lender_info($this->session->userdata('username'));
            $property_info = $this->Lender_model->get_purchased_property($mortgage_id,$lender->lender_id);
            $credit_vailable = $this->Lender_model->get_credit_available($this->session->userdata('username'));
            if ($this->Lender_model->get_purchased_property($mortgage_id,$lender->lender_id))
            {
                $data['msg'] = "<b><font color=red>You already purchased this mortgage: ".$property_info->email."</font></b>";
            }
            
            if ($credit_vailable->credit_available < 10  or $credit_vailable->credit_available < $credit_vailable->credit_available - 10)
            {
                $data['msg'] = "<b><font color=red>You don't have enough fund."."</font></b>";
            }
            
            $this->display_credit();
            
            $mortgage = array(
                'mortgage' => $mortgage_id
            );
            
            $this->session->set_userdata($mortgage);
           
            $mortgage_info = $this->Lender_model->get_mortgage_info($mortgage_id);
            $data['first_name'] = $mortgage_info->first_name;
            $data['last_name'] = $mortgage_info->last_name;
            $data['price'] = $mortgage_info->price;
            
            $this->load->view('site_lender/purchase_info',$data);
        }
        else $this->load->view('site_lender/login');
    }
    
    public function save_purchase()
    {
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {       
            $credit_vailable = $this->Lender_model->get_credit_available($this->session->userdata('username'));
            
            $lender = $this->Lender_model->get_lender_info($this->session->userdata('username'));
            $lender_id = $lender->lender_id;
            $borrower = $this->Lender_model->get_borrower_email($this->session->userdata('mortgage'));
            $borrower_email = $borrower->email;
            
            // already purchased do nothing
            if ($this->Lender_model->get_purchased_property_email($borrower->email,$lender_id))
            {
                echo "<b><font color=red>You've already purchased:</b></font> ".$borrower_email;
                echo "<a href=\"new_lead\"> GO BACK</a>";
                //echo "<a href=\"javascript:history.go(-1)\">GO BACK</a>";
            }
            else
            {
                
                if ($credit_vailable->credit_available >= 10 or $credit_vailable->credit_available - 10 >= $credit_vailable->credit_available)
                {

                    $data = array(
                        'lender_id' =>$lender_id,
                        'email' => $borrower_email,
                        'purchase_price' => 10,
                        'purchase_by' => $this->session->userdata('username')
                );            

                $amount = array(
                    'credit_available' => $credit_vailable->credit_available - 10
                );

                $this->Lender_model->update_lender_credit($lender_id,$amount);
                $this->Lender_model->add_lead($data);
                redirect('lender');
                }
                else 
                {
                    echo "<b><font color=red>You don't have enough fund to purchase.</b></font> ";
                    echo "<a href=\"new_lead\"> GO BACK</a>";
                    //echo "<a href=\"javascript:history.go(-1)\">GO BACK</a>";
                }
            }
        }
        else $this->load->view('site_lender/login');
    }

    public function new_lead_org()
    {
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {
            $data['leads'] = $this->Lender_model->get_new_lead();
            $this->load->view('site_lender/new_lead',$data);
        }
        else $this->load->view('site_lender/login');
    }
    
    public function change_password()
    {
        $data['msg'] = "";
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {
            $this->load->view('site_lender/update_password',$data);
        }
        else $this->load->view('site_lender/login');
    }
    
    public function update_password()
    {
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {
            $this->form_validation->set_rules('pwd', 'Password', 'trim|required|matches[pwd_confirm]');
            $this->form_validation->set_rules('pwd_confirm', 'Password Confirmation', 'trim|required');
            if ($this->form_validation->run() === FALSE)
            {
                $data['msg'] = "";
            }
            else 
            {
                $lender = $this->Lender_model->get_lender_info($this->session->userdata('username'));
                $data = array(
                    'pwd' => sha1($this->input->post('pwd'))
                );
                $this->Lender_model->update_pwd($lender->lender_id,$data);
                $data['msg'] = "Password has been updated.";
            }
            $this->load->view('site_lender/update_password',$data);
        }
        else $this->load->view('site_lender/login');
    }
    
    public function add_fund()
    {
        $data['msg'] = "";
        
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {   
            $this->load->view('site_lender/add_fund',$data);
        }
        else $this->load->view('site_lender/login');
    }

    public function save_add_fund()
    {
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {   
            $lender = $this->Lender_model->get_lender_info($this->session->userdata('username'));
            
            $credit_remain = $this->Lender_model->get_credit_available($this->session->userdata('username'));
            
            $this->_set_rules();
            
            if ($this->form_validation->run() === FALSE)
            {
                $data['msg'] = "";
            }            
            else 
            {
                $payment = array(
                    'company_code' => $lender->lender_id,
                    'payment_type' => $this->input->post('card_type'),
                    'username' => $this->session->userdata('username'),
                    'payment_amount' => $this->input->post('amount')
                );

                $lender_credit = array(
                    'lender_id' => $lender->lender_id,
                    'credit_available' => $this->input->post('amount') + $credit_remain->credit_available
                );
                $this->Lender_model->insert_payment($payment);
                $this->Lender_model->update_lender_credit($lender->lender_id,$lender_credit);

                $this->display_credit();
                $data['msg'] = "<b><font color=red>Add fund sucessful.</b></font>";                
            }
            
            $this->load->view('site_lender/add_fund',$data);
        }
        else $this->load->view('site_lender/login');
    }
    
    public function update_offer($purchase_id)
    {
        $data['msg'] = "";
        
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {
            $rate_info = $this->Lender_model->get_current_rate_offer($purchase_id);
            $p_id = array('pur_id' => $purchase_id);
            $this->session->set_userdata($p_id);
            $data['rate'] = $rate_info->rate_offer;            
            
            $this->load->view('site_lender/update_offer',$data);
        }
        else $this->load->view('site_lender/login');
    }
    
    public function save_new_offer()
    {
        $data['msg'] = "";
        if ($this->session->userdata('lender_logged_in') === TRUE)
        {
            $rate_info = $this->Lender_model->get_current_rate_offer($this->session->userdata('pur_id'));
            
            $data['rate'] = $rate_info->rate_offer;
            
            //echo $rate_info->transction_id;
            
            $this->form_validation->set_rules('rate_offer','Rate Offer', 'trim|required|numeric|greater_than[0]|less_than[11]');
            
            if ($this->form_validation->run() === FALSE)
            {
                $data['msg'] = "";
            }
            else 
            {
                $data = array('rate_offer' => $this->input->post('rate_offer'));
                $this->Lender_model->update_rate_offer($rate_info->transaction_id,$data);
                $data['msg'] = "Rate has been updated.";
                $rate_info = $this->Lender_model->get_current_rate_offer($this->session->userdata('pur_id'));
                $data['rate'] = $rate_info->rate_offer;
            }
            
            $lender = $this->Lender_model->get_lender_info($this->session->userdata('username'));
            
            // sending notification email to borrower
            $this->email->from('contact@vietthongtin.com', 'Mortgage Deals');
            $this->email->to($this->session->userdata('email'));
            $this->email->subject('Mortgage Offer');
            $this->email->message('Lender : '.$lender->lender_name. ' has offered you a mortgage rate.');

            $this->email->send();
            
            $this->load->view('site_lender/update_offer',$data);
        }
        else $this->load->view('site_lender/login');
    }

    public function _set_rules()
    {
        $this->form_validation->set_rules('fullname', 'Name', 'required');
        $this->form_validation->set_rules('card_number', 'Card Number', 'trim|required|numeric|min_length[16]|max_length[16]');
        $this->form_validation->set_rules('secure_code', 'Secure Code', 'trim|required|numeric|min_length[3]|max_length[3]');
        $this->form_validation->set_rules('amount', 'Amount', 'trim|required|numeric|greater_than[9]|less_than[2001]');
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('lender');
    }
	
}//end class

