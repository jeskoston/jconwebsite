<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site_admin extends CI_Controller {
    
    private $limit = 15;// records per page
    
    function __construct()
    {
        parent::__construct();
        $this->load->library(array('table','form_validation'));
        $this->load->helper('url');
        $this->load->library('grocery_CRUD');
        $this->load->model('Admin_model');
    }
    
    public function _admin_output($output = NULL)
    {
        $this->load->view('site_administrator/lender',$output);
    }
    
    public function _member_output($output = NULL)
    {
        $this->load->view('site_administrator/member',$output);
    }
    
    public function _transaction_output($output = NULL)
    {
        $this->load->view('site_administrator/purchase_info',$output);
    }

    public function index()
    {
        if ($this->session->userdata('admin_logged_in') === TRUE)
        {
            redirect('site_admin/lenders');
        }
        else $this->load->view('site_administrator/login');
    }
    
    public function lenders()
    {  
        if ($this->session->userdata('admin_logged_in') === TRUE)
        {
            $lender = new grocery_CRUD();

            $lender->set_theme('datatables');
            $lender->set_table('tbl_lender_info');
            $lender->set_subject('Lender');

            $lender->columns('lender_name','lender_address','lender_city','lender_state','lender_zipcode','lender_country')
                   ->display_as('lender_name','Lender')
                   ->display_as('lender_address','Address')
                   ->display_as('lender_city','City')
                   ->display_as('lender_state','State')
                   ->display_as('lender_zipcode','Zipcode')
                   ->display_as('lender_country','Country')
                   ->display_as('lender_phone','Phone')
                   ->display_as('lender_fax','Fax')
                   ->display_as('lender_email','Email');

            $lender->add_fields('lender_name','lender_address','lender_city','lender_state','lender_zipcode','lender_country','lender_phone','lender_fax','lender_email','lender_website');
            $lender->edit_fields('lender_name','lender_address','lender_city','lender_state','lender_zipcode','lender_country','lender_phone','lender_fax','lender_email','lender_website');

            $lender->set_relation('lender_state','tbl_state','state_name');
            $lender->set_relation('lender_country','tbl_country','country_name');
            $lender->required_fields('lender_name');
            
            $lender->set_rules('lender_state','State','required');
            $lender->set_rules('lender_country','Country','required');

            /*$lender->unset_add();
            $lender->unset_export();
            $lender->unset_print();*/
            
            $lender->callback_before_insert(array($this,'check_zipcode'));

            $output = $lender->render();
            $this->_admin_output($output);
        
        }// end authentication if
        else $this->load->view('site_administrator/login');
    }
    
    public function check_zipcode($post_array)
    {
        if(empty($post_array['lender_zipcode']))
        {
            $post_array['lender_zipcode'] = 'Not U.S.';
        }
        return $post_array;
    }

    public function create_lender_login($offset = 0)
    {
        if ($this->session->userdata('admin_logged_in') === TRUE)
        {
            // offset
            $uri_segment = 3;
            $offset = $this->uri->segment($uri_segment);

            // load data
            $lenders = $this->Admin_model->get_lender_without_login($this->limit,$offset)->result();

            // generate pagination
            $this->load->library('pagination');
            $config['base_url'] = site_url('site_admininstrator/create_lender_login/');
            $config['total_rows'] = $this->Admin_model->count_lender_without_login();
            $config['per_page'] = $this->limit;
            $config['uri_segment'] = $uri_segment;
            $this->pagination->initialize($config);
            $data['pagination'] = $this->pagination->create_links();

            // generate table data
            $this->table->set_empty("&nbsp;");
            $this->table->set_heading("No","Lender","Address","City","State","Zipcode","Action");
            $i = 0 + $offset;
            foreach ($lenders as $lender)
            {
                $this->table->add_row(++$i,$lender->lender_name,$lender->lender_address,$lender->lender_city,$lender->lender_state,$lender->lender_zipcode,
                              anchor('site_admin/create_login/'.$lender->lender_id,'Create Login',array('class'=>'update')));
            }
            $data['table'] = $this->table->generate();

            $this->load->view('site_administrator/lender_list',$data);
        }// end if
        else $this->load->view('site_administrator/login');
    }
    
    public function create_login($lender_id)
    {
        if ($this->session->userdata('admin_logged_in') === TRUE)
        {
            $data['msg'] = "";
            $lender = $this->Admin_model->get_lender_by_id($lender_id)->row();
            $lender_info = array(
                'id' => $lender_id,
                'name' => $lender->lender_name 
            );
            $this->session->set_userdata($lender_info);// need this for update tbl_lender_info

            $data['name'] = $lender->lender_name;
            $data['title'] = "Crate Login";
            $data['msg'] = "";
            $data['action'] = site_url('site_admin/save_login');
            $data['link_back'] = anchor('site_admin/create_lender_login','Back to Lenders');

            $this->load->view('site_administrator/create_login',$data);
        }// end if
        else $this->load->view('site_administrator/login');
    }
    
    public function save_login()
    {
        if ($this->session->userdata('admin_logged_in') === TRUE)
        {
            $data['msg'] = "";
            $data['title'] = "Save Login";
            $data['action'] = site_url('site_admin/save_login');
            $data['link_back'] = anchor('site_admin/lenders/','Back to Lenders');
            $data['name'] = $this->session->userdata('name');

            $this->_set_rules();

            if ($this->form_validation->run() === FALSE)
            {
                $data['msg'] = "";
            }
            else
            {
                // validate username if it isn't existed
                if (!$this->Admin_model->check_username($this->input->post('username')))
                {
                    // assign data
                    $username = array(
                        'username' => $this->input->post('username')
                    );
                    // update username for tbl_lender_info
                    $this->Admin_model->update_username($this->session->userdata('id'),$username);

                    // set default password = spring13 and last 3 character from usename
                    $pwd = 'spring13'.substr($this->input->post('username'), -3);

                    // assign login data
                    $login_info = array(
                        'lender_id' => $this->session->userdata('id'),
                        'username' => $this->input->post('username'),
                        'pwd' => sha1($pwd),
                        'status' => 1,
                        'user_type' => 2
                    );
                    // insert login info into tbl_login_info
                    $this->Admin_model->add_username($login_info);
                    
                    // insert lender credit 
                    $credit_info = array(
                        'lender_id' => $this->session->userdata('id'),
                        'username' => $this->input->post('username'),
                        'credit_available' => 0
                    );
                    $this->Admin_model->insert_lender_credit($credit_info);

                    // display message
                    $data['msg'] = '<div class="success">add login success</div>';
                }
                else 
                {
                    $data['msg'] = "<font color=red>Username <b>".$this->input->post('username')."</b> has been taken. Choose a different one.</font>";
                }

            }
            $this->load->view('site_administrator/create_login',$data);
        }
        else $this->load->view('site_administrator/login');
    }

    public function member()
    {
        if ($this->session->userdata('admin_logged_in') === TRUE)
        {
            $member = new grocery_CRUD();
            $member->set_theme('datatables');
            $member->set_table('tbl_member_info');
            
            $member->columns('first_name','last_name','address','city','state','zipcode','country','phone');
            $member->display_as('first_name', 'First Name')
                   ->display_as('last_name', 'Last Name')
                   ->display_as('address', 'Address')
                   ->display_as('city', 'City')
                   ->display_as('state', 'State')
                   ->display_as('zipcode', 'Zip Code')
                   ->display_as('phone', 'Phone');
            
            $member->set_relation('state','tbl_state','state_name');
            $member->set_relation('country','tbl_country','country_name');
            
            $member->edit_fields('first_name','last_name','address','city','state','zipcode','country','phone','mobile');
            
            $member->unset_add();
            /*$member->unset_export();
            $member->unset_print();
            $member->unset_delete();*/
            
            $output = $member->render();
            $this->_member_output($output);
           
        }// end authentication if
        else $this->load->view('site_administrator/login');
    }
    
    public function transaction()
    {
        if ($this->session->userdata('admin_logged_in') === TRUE)
        {
            $trans = new grocery_CRUD();
            $trans->set_theme('datatables');
            $trans->set_table('tbl_purchase_info');
            $trans->columns('email','purchase_price','date_purchase','purchase_by','purchase_status','borrower_status');
            $trans->display_as('email','Borrower Email')
                  ->display_as('purchase_price','Price')
                  ->display_as('date_purchase','Date Purchase')
                  ->display_as('purchase_by','Lender ID')
                  ->display_as('purchase_status','Lender Status')
                  ->display_as('borrower_status','Offer Status');
            
            $trans->unset_add();
            $trans->unset_export();
            $trans->unset_print();
            $trans->unset_delete();
            $trans->unset_edit();
            
            //$trans->add_action('Details','','site_admin/trans_detail');
            $output = $trans->render();
            $this->_transaction_output($output);
        }
    }

    public function add_lender()
    {
        $this->load->view('site_administrator/add_lender');
    }

    public function my_account()
    {
        $this->load->view('site_administrator/my_account');
    }
    
    public function login()
    {
        $data['msg'] = "";
        
        if ($this->Admin_model->authenticate_user($this->input->post('username'),$this->input->post('password')))
        {
            $data = array(
                'username' => $this->input->post('username'),
                'user_type' => 1,
                'admin_logged_in' => TRUE
            );
            $this->session->set_userdata($data);
            redirect('site_admin/lenders');
        }
        else 
        {
            $data['msg'] = "Invalid Username or/and Password";
            $this->load->view('site_administrator/login',$data);
        }
        
    }

    public function logout()
    {
        $this->session->sess_destroy();
	redirect('site_admin');
    }

    public function _set_rules()
    {
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_error_delimiters('<p class="error">', '</p>');
    }
	
}//end class