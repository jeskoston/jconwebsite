<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library(array('table','form_validation','email'));
        $this->load->model('Member_model');
    }

    public function index()
    {
        $data['msg'] = "";
        $this->load->view('home_page',$data);		
    }

    public function create_profile()
    {
        $data['msg'] = "";
        $this->load->view('form',$data);
    }
    
    public function forgot_password()
    {
        $data['msg'] = "";
        $this->load->view('retrive_pwd',$data);
    }
    
    public function send_pwd()
    {
        $data['msg'] = "";
        
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        
        if ($this->form_validation->run() === FALSE)
        {
            $data['msg'] = "";
        }
        else
        {
            if ($this->Member_model->check_email($this->input->post('email')))
            {
                $random = substr(number_format(time() * rand(),0,'',''),0,10);
                
                $tmp_pwd = array(
                    'pwd' => sha1($random)
                );
                $this->Member_model->update_pwd($this->input->post('email'),$tmp_pwd);
                
                $this->email->from('contact@vietthongtin.com', 'Mortgage Deals');
                $this->email->to($this->input->post('email'));

                //$this->email->cc('another@another-example.com');
                //$this->email->bcc('them@their-example.com');

                $this->email->subject('Forgot password');
                $this->email->message('Your new password is: '.$random);

                $this->email->send();

                //echo $this->email->print_debugger();
                $data['msg'] = "Password has been sent to your email."; 
            }
            else
            {
                 $data['msg'] = "Email provided is not registered with us. Please double check your email.";
            }
        }
        
        $this->load->view('retrive_pwd',$data);
    }

    public function save_profile()
    {
        $this->_set_rules();
        
        if ($this->form_validation->run() === FALSE)
        {
            $data['msg'] = "";
        }
        else 
        {
            // check if email isn't existed
            if (! $this->Member_model->check_email($this->input->post('email')))
            {
                $login_info = array(
                'username' => $this->input->post('email'),
                'pwd' => sha1($this->input->post('pwd')),
                'status' => 1,
                'user_type' => 3
                );
                // add login info
                $this->Member_model->add_login($login_info);

                $user_info = array(
                    'email' => $this->input->post('email'),
                    'first_name' => $this->input->post('first_name'),
                    'last_name' => $this->input->post('last_name')
                );
                // add user info into
                $this->Member_model->add_profile($user_info);
                $data['msg'] = '<div class="success">Create Profile Sucess</div>'.
                        "<br>Login to update your profile.";
            }
            else $data['msg'] = "<font color=red>Email <b>".$this->input->post('email')."</b> has been registerd.</font>";
        }
        // display form if there are errors
        $this->load->view('form',$data);
    }
    
    public function _set_rules()
    {
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('pwd', 'Password', 'trim|required|matches[pwd_confirm]');
        $this->form_validation->set_rules('pwd_confirm', 'Password Confirmation', 'trim|required');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('city','City','trim|required');
    }
	
}// end site class

