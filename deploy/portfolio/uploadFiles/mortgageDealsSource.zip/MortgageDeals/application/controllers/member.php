<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Member extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('Member_model');
        $this->load->library('grocery_CRUD');
    }
    
    public function _member_output($output = NULL)
    {
       $this->load->view('site_member/my_account',$output); 
    }
    
    public function _mortgage_output($output = NULL)
    {
       $this->load->view('site_member/mortgate_profile',$output);
    }
    
    public function _offer_output($output = NULL)
    {
        $this->load->view('site_member/home',$output);
    }

    public function login()
    {
        $data['msg'] = "";
        
        if ($this->Member_model->authenticate_user($this->input->post('email'),$this->input->post('pwd')))
        {
            $data = array(
                'username' => $this->input->post('email'),
                'user_type' => 3,
                'member_logged_in' => TRUE
            );
            $this->session->set_userdata($data);
            redirect('member');
        }
        else 
        {
            $data['msg'] = "<font color=red>Invalid Username or/and Password</font>";
            $this->load->view('home_page',$data);
        }
    }

    public function index()
    {
        $data['msg'] = "";
        
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            $offer = new grocery_CRUD();
            $offer->set_theme('datatables');
            $offer->set_table('tbl_transaction');
            $offer->where('borrower_email',$this->session->userdata('username'));
            $offer->columns('rate_offer','offer_by','date_offer','borrower_status');
            $offer->display_as('rate_offer','Interest Rate')
                  ->display_as('offer_by','Lender ID')
                  ->display_as('date_offer','Date Offer')
                  ->display_as('borrower_status','My Option');
            $offer->unset_add();
            $offer->unset_export();
            $offer->unset_print();
            $offer->unset_delete();
            $offer->unset_edit();
            $offer->add_action('View Mortgage Details','','member/mortgage_detail');
            $offer->add_action('View Lender','','member/lender_detail');
            
            $output = $offer->render();
            $this->_offer_output($output);
        }
        else $this->load->view('home_page',$data);		
    }
    
    public function mortgage_detail($transaction_id)
    {
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            $mortgage_info = $this->Member_model->get_rate_offer($transaction_id);
            $id = array('trans_id' => $transaction_id);
            $this->session->set_userdata($id);
            
            $loan_amount = $mortgage_info->loan_amount;
            $amount = str_replace( ',', '', $loan_amount );
            $down_percent = $mortgage_info->down_percent;
            $down = str_replace('%','',$down_percent);
            $term = "360";//30 year term
            
            $rate = $mortgage_info->rate_offer;
            // loan amount, downpayment percent, rate from the bank, length of loan to be repaid
            $this->CalculateMonthlyPaymentsAdvanced($amount, $down, $rate, $term);
        }
    }
    
    function CalculateMonthlyPaymentsAdvanced($price, $down,$rate,$terminmonths) 
    {
        
        $data['msg'] = "";
        
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            $handle = curl_init();
            $ourZillowId = 'X1-ZWz1bi4ag3r1u3_88dza';//zillow developer id
            $schedule='none';//can switch form monthly,yearly,both,none

            curl_setopt_array($handle, array(CURLOPT_URL => 'http://www.zillow.com/webservice/mortgage/CalculateMonthlyPaymentsAdvanced.htm',
                CURLOPT_POST => false,
                /*Might need later for more implementation
                CURLOPT_POSTFIELDS => 'zws-id=' . $ourZillowId . '&price=' . $price . '&down=' . $down .
                                      '&rate='.$rate .'&terminmonths='.$terminmonths. '&schedule='.$schedule.
                                       '&propertytax=2000'.'&hazard=1000'.'&pmi=150'.'&zip=98103'.'&hoa=3200',
                */
                  CURLOPT_POSTFIELDS => 'zws-id=' . $ourZillowId . '&price=' . $price . '&down=' . $down .
                                      '&rate='.$rate .'&terminmonths='.$terminmonths. '&schedule='.$schedule,

                CURLOPT_RETURNTRANSFER => true)
            );

            $response = curl_exec($handle);
            $xml = simplexml_load_string($response, 'SimpleXMLElement', LIBXML_NOCDATA);
            $xm2 = simplexml_load_string($response);
            
            // get value from our database
            $mortgage_info = $this->Member_model->get_rate_offer($this->session->userdata('trans_id'));
            $data['loan_amount'] = $mortgage_info->loan_amount;
            $data['down_percent'] = $mortgage_info->down_percent;
            $data['rate'] = $mortgage_info->rate_offer;
            $data['lender_url'] = $mortgage_info->lender_website;
            
            // use zillow API
            $data ['monthly_payment'] =(string)$xm2->response->monthlyprincipalandinterest;

            $this->load->view('site_member/pre_cal_mortgage',$data);

            curl_close($handle);
        }
    }

    public function lender_detail($transaction_id)
    {
        $data['msg'] = "";
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            $lender_info = $this->Member_model->get_lender_detail($transaction_id);
            $data['rate_offer'] = $lender_info->rate_offer;
            $data['lender'] = $lender_info->lender_name;
            $data['address'] = $lender_info->lender_address;
            $data['city'] = $lender_info->lender_city;
            $data['state'] = $lender_info->state_name;
            $data['zipcode'] = $lender_info->lender_zipcode;
            $data['phone'] = $lender_info->lender_phone;
            $data['fax'] = $lender_info->lender_fax;
            $data['email'] = $lender_info->lender_email;
            $id = array('trans_id' => $transaction_id);
            $this->session->set_userdata($id);
            $this->load->view('site_member/lender_detail',$data);
        }
        else $this->load->view('home_page',$data);
    }
    
    public function update_offer()
    {
        $data['msg'] = "";
        
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            $lender_info = $this->Member_model->get_lender_detail($this->session->userdata('trans_id'));
            $data['rate_offer'] = $lender_info->rate_offer;
            $data['lender'] = $lender_info->lender_name;
            $data['address'] = $lender_info->lender_address;
            $data['city'] = $lender_info->lender_city;
            $data['state'] = $lender_info->state_name;
            $data['zipcode'] = $lender_info->lender_zipcode;
            $data['phone'] = $lender_info->lender_phone;
            $data['fax'] = $lender_info->lender_fax;
            $data['email'] = $lender_info->lender_email;
            // has borrower already made any offer?
            $status = "Accept Offer";
            if ($this->Member_model->verify_borrower_offer($this->session->userdata('username'),$status))
            {
                $data['msg'] = "There is only one offer can be made. You have already made offer for Lender <b>".$lender_info->lender_name."</b>";
                $this->load->view('site_member/lender_detail',$data);
            }
            else 
            {
                $data = array(
                'borrower_status' => $this->input->post('offer_option')
            );
            $this->Member_model->update_transaction($this->session->userdata('trans_id'),$data);
            
            $data_purchase = array(
                'borrower_status' => $this->input->post('offer_option')
            );
            $this->Member_model->update_purchase_info($lender_info->lender_id,$this->session->userdata('username'),$data_purchase);
            
            $data_mortgage = array(
                'borrower_status' => "Closed"
            );
            $this->Member_model->update_mortgage_info($this->session->userdata('username'),$data_mortgage);
            
            redirect('member');
            }
        }
        else $this->load->view('home_page',$data);
    }

    public function my_account()
    {
        $data['msg'] = "";
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            $member = new grocery_CRUD();
            $member->set_theme('datatables');
            $member->set_table('tbl_member_info');
            $member->where('email',$this->session->userdata('username'));
            
            $member->columns('first_name','last_name','address','city','state','zipcode','country','phone');
            $member->display_as('first_name', 'First Name')
                   ->display_as('last_name', 'Last Name')
                   ->display_as('address', 'Address')
                   ->display_as('city', 'City')
                   ->display_as('state', 'State')
                   ->display_as('zipcode', 'Zip Code')
                   ->display_as('phone', 'Phone');
            
            $member->set_relation('state','tbl_state','state_name');
            $member->set_relation('country','tbl_country','country_name');
            
            $member->edit_fields('first_name','last_name','address','city','state','zipcode','country','phone','mobile');
            
            $member->unset_add();
            $member->unset_export();
            $member->unset_print();
            $member->unset_delete();
            $member->add_action('Change Password','','member/change_password');
            $output = $member->render();
            $this->_member_output($output);
        }
        else $this->load->view('home_page',$data);
    }
    
    public function save_morgate_profile()
    {
        $data['msg'] = "";
        
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            if (! $this->Member_model->check_mortgage_profile($this->session->userdata('username')))
            {
                echo "Used as: ".$this->input->get('used');
                echo "<br>State: ".$this->input->get('state');
                echo "<br>City: ".$this->input->get('city');
                echo "<br>Loan: ".$this->input->get('amount');
                echo "<br>Down: ".$this->input->get('down');
                echo "<br>Credit: ".$this->input->get('credit');
                echo "<br>Foreclosure: ".$this->input->get('foreclosure');
                echo "<br>Debt: ".$this->input->get('debt');
                
                $data = array(
                    'email' =>$this->session->userdata('username'),
                    'property_usage' =>$this->input->get('used'),
                    'state' => $this->input->get('state'),
                    'city' =>$this->input->get('city'),
                    'loan_amount' =>$this->input->get('amount'),
                    'down_percent' =>$this->input->get('down'),
                    'credit_rating' =>$this->input->get('credit'),
                    'foreclosure' =>$this->input->get('foreclosure'),
                    'credit_debt' =>$this->input->get('debt'),
                    'borrower_status' => 'Open'
                );
                $this->Member_model->add_mortgate_profile($data);
                
                // insert a default of $10 into price calculation
                $price = array(
                    'email' => $this->session->userdata('username'),
                    'price' => 10
                );
                
                $this->Member_model->insert_member_price($price);
                echo "<br>Sucesfull create profile. <a href=\"my_mortgage_profile\">View My Mortgage Profile</a>";
            }
            else echo "<font color=red>You cannot create more than one mortgate profile.</font>";
        }
        else $this->load->view('home_page',$data);        
    }
    
    public function change_password()
    {
        $data['msg'] = "";
        
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            $this->load->view('site_member/update_password',$data);
        }
        else $this->load->view('home_page',$data);
    }
    
    public function update_password()
    {
        $data['msg'] = "";
        
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            $this->form_validation->set_rules('pwd', 'Password', 'trim|required|matches[pwd_confirm]');
            $this->form_validation->set_rules('pwd_confirm', 'Password Confirmation', 'trim|required');
            
            if ($this->form_validation->run() === FALSE)
            {
                $data['msg'] = "";
            }
            else 
            {
                $data = array(
                    'pwd' => sha1($this->input->post('pwd'))
                );
                $this->Member_model->update_pwd($this->session->userdata('username'),$data);
                $data['msg'] = "Password has been updated.";
            }
            $this->load->view('site_member/update_password',$data);
        }
        else $this->load->view('home_page',$data);
    }
    public function my_mortgage_profile()
    {
        $data['msg'] = "";
        
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            $mortgate = new grocery_CRUD();
            $mortgate->set_theme('datatables');
            $mortgate->set_table('tbl_mortgate_profile');
            $mortgate->where('email',$this->session->userdata('username'));
            
            $mortgate->columns('property_usage','city','state','zipcode','loan_amount','down_percent','credit_rating','foreclosure','credit_debt');
            
            $mortgate->display_as('property_usage','Use Property As')
                     ->display_as('city','City')
                     ->display_as('state','State')
                     ->display_as('zipcode','Zip Code')
                     ->display_as('loan_amount','Loan Amount')
                     ->display_as('down_percent','Down Percent')
                     ->display_as('credit_rating','Credit Rating')
                     ->display_as('foreclosure','Foreclose')
                     ->display_as('credit_debt','All Credit Debt');
            
            $mortgate->edit_fields('property_usage','city','state','zipcode','loan_amount','down_percent','credit_rating','foreclosure','credit_debt');
            
            $mortgate->set_relation('state','tbl_state','state_name');
            
            $mortgate->unset_add();
            
            $output = $mortgate->render();
            $this->_mortgage_output($output);
        }
        else $this->load->view('home_page',$data);
    }
    
    public function mortgage_profile()
    {
        $data['msg'] = "";
        
        if ($this->session->userdata('member_logged_in') === TRUE)
        {
            if (! $this->Member_model->check_mortgage_profile($this->session->userdata('username')))
            {
               $this->load->view('site_member/mortgage_form', $data);
            }
            else $this->my_mortgage_profile();
        }
        else $this->load->view('home_page',$data);
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('site');
    }
	
}// end site class

