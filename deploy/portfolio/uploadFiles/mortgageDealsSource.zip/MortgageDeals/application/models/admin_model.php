<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    public function authenticate_user($username,$password)
    {
        $this->db->where('username', $username);
        $this->db->where('pwd', sha1($password));
        $this->db->where('user_type',1);
        $query = $this->db->get('tbl_login_info');

        if($query->num_rows === 1)
        {
            /*foreach ($query->result() as $row)
            {
                $login_info = array(
                    'username' => $row->username,
                    'user_type' => $row->user_type,
                    'admin_logged_in' => TRUE
                );
            }
            $this->session->set_userdata($login_info); */
            
            return TRUE;
        }
    }
    
    // get lender without login info
    public function get_lender_without_login($limit, $offset = 0)
    {     
        $this->db->order_by('lender_id','ASC');
        return $this->db->get_where('tbl_lender_info',array('username'=>''),$limit,$offset);
    }    
    
    public function count_lender_without_login()
    {
        $this->db->where('username','');
        $this->db->from('tbl_lender_info');
        return $this->db->count_all_results();
    }

    public function get_lender_by_id($id)
    {
        $this->db->where('lender_id', $id);
        return $this->db->get('tbl_lender_info');
    }
    
    public function check_username($username)
    {
        $query = "SELECT username FROM tbl_login_info WHERE username = ? ";
        $result = $this->db->query($query,$username);
        
        if ($result->num_rows() > 0)
        {
            return TRUE; // username existed
        }
        else return FALSE;
    }
    
    public function update_username($lender_id,$username)
    {
        $this->db->where('lender_id',$lender_id);
        $this->db->update('tbl_lender_info',$username);
    }
    
    public function add_username($login_info)
    {
        $this->db->insert('tbl_login_info',$login_info);
    }
    
    public function save_category($category)
    {
        $this->db->insert($this->tbl_business_category,$category);

        return $this->db->insert_id();
    }

    public function update_category($id, $category){
        $this->db->where('id', $id);
        $this->db->update($this->tbl_business_category, $category);
    }

    public function delete_category($id){
        $this->db->where('id', $id);
        $this->db->delete($this->tbl_business_category);
    }

    public function count_all(){
        return $this->db->count_all($this->tbl_business_category);
    }
    
    public function insert_lender_credit($credit_info)
    {
        $this->db->insert('tbl_lender_credit',$credit_info);
    }
	
} // end class

?>