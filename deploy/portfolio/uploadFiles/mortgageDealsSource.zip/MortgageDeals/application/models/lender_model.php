<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Lender_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    public function authenticate_user($username,$password)
    {
        $this->db->where('username', $username);
        $this->db->where('pwd', sha1($password));
        $this->db->where('user_type',2);
        $query = $this->db->get('tbl_login_info');

        if($query->num_rows === 1)
        {
            return TRUE;
        }
    }
    
    public function get_lender_info($username)
    {
        $this->db->where('username',$username);
        $query = $this->db->get('tbl_lender_info');
        
        if ($query->num_rows === 1)
        {
            return $query->row();
        }        
    }
    
    public function get_new_lead()
    {
        $query = "SELECT login.*,member.* FROM tbl_login_info login 
            JOIN tbl_member_info member ON login.username = member.email 
            AND login.user_type = 3";
		
        $result = $this->db->query($query);

        if ($result->num_rows() > 0 )
        {
            foreach ($result->result() as $row)
            {
                $data[] = $row;
            }
            return $data;
        }
    }
    
    public function get_credit_available($username)
    {
        $query = "SELECT * FROM tbl_lender_credit WHERE username = ?";
        
        $result = $this->db->query($query,$username);
        
        if ($result->num_rows() > 0)
        {
            return $result->row();
        }        
    }
    
    public function get_mortgage_info($mortgage_id)
    {
        $query = "SELECT p.*,m.*,i.* FROM tbl_price_calculation p 
                  JOIN tbl_mortgate_profile m ON p.email = m.email 
                  JOIN tbl_member_info i ON m.email = i.email
                  WHERE m.property_id = ?";
        
        $result = $this->db->query($query,$mortgage_id);
        
        if ($result->num_rows() > 0)
        {
            return $result->row();
        }
    }
    
    public function get_borrower_email($mortgage_id)
    {
        $this->db->where('property_id',$mortgage_id);
        
        $query = $this->db->get('tbl_mortgate_profile');
        
        if ($query->num_rows === 1)
        {
            return $query->row();
        }   
    }
    
    public function get_borrower_info($purchase_id)
    {
        $query = "SELECT purchase_info.*,borrower_info.*,state.* as state_name,mortgage_profile.*
		  FROM tbl_purchase_info purchase_info
                  JOIN tbl_member_info borrower_info ON purchase_info.email = borrower_info.email
                  JOIN tbl_state state ON state.state_id = borrower_info.state
                  JOIN tbl_mortgate_profile mortgage_profile ON mortgage_profile.email = purchase_info.email
                  WHERE purchase_info.purchase_id = ? ";
        
        $result = $this->db->query($query,$purchase_id);
        
        if ($result->num_rows() > 0)
        {
            return $result->row();
        }
    }
    
    public function get_purchased_property($m_id,$l_id)
    {
        $query = "SELECT mortgage_profile.*,purchase_info.*
                  FROM tbl_mortgate_profile mortgage_profile
                  JOIN tbl_purchase_info purchase_info
                  ON mortgage_profile.email = purchase_info.email
                  WHERE mortgage_profile.property_id = ?
                  AND purchase_info.lender_id = ?";
        
        $result = $this->db->query($query,array($m_id,$l_id));
        
        if ($result->num_rows() > 0)
        {
            return $result->row();
        }
    }
    
    public function get_purchased_property_email($email,$l_id)
    {
        $query = "SELECT property.email,purchase.email 
                  FROM tbl_mortgate_profile property
                  JOIN tbl_purchase_info purchase
                  ON property.email = purchase.email
                  WHERE purchase.email = ?
                  AND lender_id = ? ";
        
        $result = $this->db->query($query, array($email,$l_id));
        
        if ($result->num_rows() > 0)
        {
            return $result->row();
        }
    }
    
   /* public function get_accept_lender_info($purchase_id)
    {
       
        
        $query = "SELECT purchase.*,lender.* FROM tbl_purchase_info purchase
                  JOIN tbl_lender_info lender ON purchase.lender_id = lender.lender_id
                  WHERE purchase.borrower_status ='Accept Offer' AND purchase.purchase_id =? ";
        
        $result = $this->db->query($query,$purchase_id);
        
        if ($result->num_rows() > 0)
        {
            return $result->row();
        }
    }*/

    public function add_lead($data)
    {
        $this->db->insert('tbl_purchase_info',$data);
    }
    
    public function insert_payment($payment)
    {
        $this->db->insert('tbl_payment_info',$payment);
    }
    
    public function update_lender_credit($lender_id,$amount)
    {
        $this->db->where('lender_id', $lender_id);
        $this->db->update('tbl_lender_credit',$amount);
    }
    
    public function add_transaction($data)
    {
        $this->db->insert('tbl_transaction',$data);
    }
    
    public function update_purchase_info($purchase_id,$data)
    {
        $this->db->where('purchase_id',$purchase_id);
        $this->db->update('tbl_purchase_info',$data);
    }
    
    public function update_pwd($id,$data)
    {
        $this->db->where('lender_id',$id);
        $this->db->update('tbl_login_info',$data);
    }
    
    public function get_current_rate_offer($id)
    {
        $query = "SELECT p.*,t.* FROM tbl_purchase_info p 
                  JOIN tbl_transaction t ON p.email = t.borrower_email
                  WHERE p.purchase_id = ? ";
        
        $result = $this->db->query($query, $id);
        
        if ($result->num_rows() > 0)
        {
            return $result->row();
        }   
    }

    public function update_rate_offer($t_id,$data)
    {
        $this->db->where('transaction_id',$t_id);
        $this->db->update('tbl_transaction',$data);
    }
	
} // end class

?>