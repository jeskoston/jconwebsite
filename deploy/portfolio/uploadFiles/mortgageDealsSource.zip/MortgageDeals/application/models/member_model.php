<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Member_model extends CI_Model
{
    function __construct()
    {
         parent::__construct();
    }
    
    public function authenticate_user($email,$pwd)
    {
        $this->db->where('username', $email);
        $this->db->where('pwd', sha1($pwd));
        $this->db->where('user_type',3);
        $query = $this->db->get('tbl_login_info');

        if($query->num_rows === 1)
        {
            return TRUE;
        }
    }
    
    public function check_email($email)
    {
        $query = "SELECT username FROM tbl_login_info WHERE username = ? ";
        
        $result = $this->db->query($query,$email);
        
        if ($result->num_rows() > 0)
        {
            return TRUE; // email existed
        }
        else return FALSE;
    }

    public function add_login($data)
    {
        $this->db->insert('tbl_login_info',$data);
    }
    
    public function add_profile($data)
    {
        $this->db->insert('tbl_member_info',$data);
    }
    
    public function check_mortgage_profile($email)
    {
       $query = "SELECT email FROM tbl_mortgate_profile WHERE email = ? ";
       
       $result = $this->db->query($query,$email);
        
        if ($result->num_rows() > 0)
        {
            return TRUE; // email existed
        }
        else return FALSE; 
    }
    
    public function get_lender_detail($transaction_id)
    {
        $query = "SELECT transaction_info.rate_offer,lender_info.*,state.* as state_name
                  FROM tbl_transaction transaction_info 
                  JOIN tbl_lender_info  lender_info ON transaction_info.lender_id = lender_info.lender_id
                  JOIN tbl_state state ON state.state_id = lender_info.lender_state
                  WHERE transaction_info.transaction_id = ?";
        
        $result = $this->db->query($query,$transaction_id);
        
        if ($result->num_rows() > 0)
        {
            return $result->row();
        }
    }

    public function add_mortgate_profile($data)
    {
        $this->db->insert('tbl_mortgate_profile',$data);
    }
    
    public function insert_member_price($data)
    {
        $this->db->insert('tbl_price_calculation',$data);
    }
    
    public function update_pwd($username,$data)
    {
        $this->db->where('username',$username);
        $this->db->update('tbl_login_info',$data);
    }
    
    public function update_transaction($id,$data)
    {
        $this->db->where('transaction_id',$id);
        $this->db->update('tbl_transaction',$data);
    }
    
    public function update_purchase_info($lender_id,$user_email,$data)
    {
        $this->db->where('lender_id',$lender_id);
        $this->db->where('email',$user_email);
        $this->db->update('tbl_purchase_info',$data);
    }
    
    public function update_mortgage_info($email,$data)
    {
        $this->db->where('email',$email);
        $this->db->update('tbl_mortgate_profile',$data);
    }
    
    public function verify_borrower_offer($email,$status)
    {
        $query = "select * from tbl_transaction where borrower_email = ? and borrower_status = ?";
        
        $result = $this->db->query($query,array($email,$status));
        
        if ($result->num_rows() > 0 )
        {
            return TRUE;
        }
    }
    
    public function get_rate_offer($tran_id)
    {
        $query = "SELECT p.*,m.*,l.* FROM tbl_transaction p 
                  JOIN tbl_mortgate_profile m ON p.borrower_email = m.email
                  JOIN tbl_lender_info l ON p.lender_id = l.lender_id
                  WHERE p.transaction_id = ?";
        
        $result = $this->db->query($query,$tran_id);
        
        if ($result->num_rows === 1)
        {
            return $result->row();
        }
    }
  
   public function get_states()
    {
        $this->db->select('state_id,state_name');
        
        $query = $this->db->get('tbl_state');

        $states = array();

        if($query->result())
        {
            $states[''] = "Select State";
            foreach ($query->result() as $state) 
            {
                $states[$state->state_id] = $state->state_name;// display in drop down
            }
            return $states;
        }
        else
        {
          return FALSE;
        }
    }
	
} // end class

?>