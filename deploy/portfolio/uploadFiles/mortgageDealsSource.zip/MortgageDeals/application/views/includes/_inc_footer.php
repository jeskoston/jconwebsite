<div id="footer-content">
		
		</div>
	
		<div id="footer-bottom">
	
			<p class="bottom-left">			
			&nbsp; &copy;<?php echo (date("Y"));?> all rights reserved &nbsp; &nbsp;
			</p>	

			<p class="bottom-right" >
				<a href="<?=base_url();?>">Home</a> |
				<a href="<?=base_url('site/create_profile');?>">Create Profile</a>
			</p>
	
		</div>	