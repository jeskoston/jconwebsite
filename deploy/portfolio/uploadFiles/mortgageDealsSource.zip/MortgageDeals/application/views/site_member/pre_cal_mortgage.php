<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />

<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url('assets/css/KeepItSimple.css');?>" />

</head>
<body>

	<!-- header starts-->
	<?php $this->load->view('site_member/includes/_inc_menu_home'); ?>
	<!-- header ends here -->
	</div></div>
	
	<!-- content starts -->
	<div id="content-outer"><div id="content-wrapper" class="container_16">
	
		<!-- main -->
		<div id="main" class="grid_8">
                
		<p><?php echo $msg;?>
                                <table border="1" width="100%">
                                    <tr>
                                    <td colspan="2"><b>Pre calculate mortgage</b></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Loan Amount</td>
                                    <td><?php echo "$".$loan_amount; ?></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Down Payment</td>
                                    <td><?php echo $down_percent; ?></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Interest Rate</td>
                                    <td><?php echo $rate; ?></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Payment Term</td>
                                    <td><?php echo "30 Year"; ?></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Estimate Monthly Payment</td>
                                    <td><?php echo "$".$monthly_payment; ?></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Lender URL</td>
                                    <td>                                        
                                        <?php echo "<a href='http://$lender_url'>View Lender Website</a>"; ?>
                                    </td>
                                    </tr>
                                    </table>
                        </p>
		
                    
		</div>
                <!-- main ends -->
	
	<!-- contents end here -->	
	</div></div>

	<!-- footer starts here -->	
	<div id="footer-wrapper" class="container_16">
	
		<?php $this->load->view('site_member/includes/_inc_footer');?>
			
	</div>
	<!-- footer ends here -->

</body>
</html>
