<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />
<!--The stylesheet to be used for the particular page form_style.css-->
<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/form_style.css');?>" media="all" />
<!--Linking all of the jquery libraries to be used-->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?=base_url('assets/js/jquery.inputfocus-0.9.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('assets/js/jquery.main.js');?>"></script>

</head>
<body>

<div id="container">
        <form action="#" method="post">
	
            <!-- #first_step, select the type of property the user is looking for -->
            <div id="first_step">
                <h1><span>PROPERTY</span> INFO</h1>
                <div class="form">
                     <select id="property_used" name="property_used">
                        <option>Primary Residence</option>
                        <option>Secondary Home</option>
                        <option>Investment</option>
                    </select>                    
                    <label for="property_used">Property Usage </label> <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
                    <!--Which state is the property in?-->
                    <select id="property_state" name="property_state">
                        <option value="1">Alabama</option>
                        <option value="2">Alaska</option>
                        <option value="3">Arizona</option>
                        <option value="4">Arkansas</option>
                        <option value="5">California</option>
                        <option value="6">Colorado</option>
                        <option value="7">Connecticut</option>
                        <option value="8">Delaware</option>
                        <option value="9">District of Columbia</option>
                        <option value="10">Florida</option>
                        <option value="11">Georgia</option>
                        <option value="12">Hawaii</option>
                        <option value="13">Idaho</option>
                        <option value="14">Illinois</option>
                        <option value="15">Indiana</option>
                        <option value="16">Iowa</option>
                        <option value="17">Kansas</option>
                        <option value="18">Kentucky</option>
                        <option value="19">Louisiana</option>
                        <option value="20">Maine</option>
                        <option value="21">Montana</option>
                        <option value="22">Nebraska</option>
                        <option value="23">Nevada</option>
                        <option value="24">New Hampshire</option>
                        <option value="25">New Jersey</option>
                        <option value="26">New Mexico</option>
                        <option value="27">New York</option>
                        <option value="28">North Carolina</option>
                        <option value="29">North Dakota</option>
                        <option value="30">Ohio</option>
                        <option value="31">Oklahoma</option>
                        <option value="32">Oregon</option>
                        <option value="33">Maryland</option>
                        <option value="34">Massachusetts</option>
                        <option value="35">Michigan</option>
                        <option value="36">Minnesota</option>
                        <option value="37">Mississippi</option>
                        <option value="38">Missouri</option>
                        <option value="39">Pennsylvania</option>
                        <option value="40">Rhode Island</option>
                        <option value="41">South Carolina</option>
                        <option value="42">South Dakota</option>
                        <option value="43">Tennessee</option>
                        <option value="44">Texas</option>
                        <option value="45">Utah</option>
                        <option value="46">Vermont</option>
                        <option value="47">Virginia</option>
                        <option value="48">Washington</option>
                        <option value="49">West Virginia</option>
                        <option value="50">Wisconsin</option>
                        <option value="51">Wyoming</option>
                    </select>
                    
                    <!--php //echo form_dropdown('property_state', $state); ?-->
                    
                    <label for="property_state">Property State </label>
                    
                    <!--label for="property_city">Property City </label-->
                    
                    <input type="text" name="property_city" id="property_city" value="Property City" />
                    <label for="property_city">At least 4 characters.</label>
                   
                </div><!-- clearfix --><div class="clear"></div><!-- /clearfix -->
                <input class="submit" type="submit" name="submit_first" id="submit_first" value="" />
            </div>      <!-- clearfix --><div class="clear"></div><!-- /clearfix -->


            <!-- #second_step, what kind of loan is the user looking for? How much? How much down? -->
            <div id="second_step">
                <h1><span>LOAN</span> AMOUNT</h1>

                <div class="form">
                    <select id="loan_amount" name="loan_amount">
                        <option>400,000</option>
                        <option>300,000</option>
                        <option>200,000</option>
                    </select>
                    <label for="loan_amount">Estimate Loan Amount </label>
                    <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
                    
                     <select id="down_percent" name="down_percent">
                        <option>5%</option>
                        <option>10%</option>
                        <option>15%</option>
                        <option>20%</option>
                        <option>25%</option>
                    </select>
                    <label for="down_percent">Down Payment Percent </label> <!-- clearfix --><div class="clear"></div><!-- /clearfix -->       
                </div>      <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
                <input class="submit" type="submit" name="submit_second" id="submit_second" value="" />
            </div>      <!-- clearfix --><div class="clear"></div><!-- /clearfix -->


            <!-- #third_step, checking the users credit/forclosure history  -->
            <div id="third_step">
                <h1><span>CREDIT</span> RATING</h1>

                <div class="form">
                    <select id="credit_rating" name="credit_rating">
                        <option>Excellent (720+)</option>
                        <option>Good (680 - 719)</option>
                        <option>Fair (640 - 679)</option>
                        <option>Poor (639 or less)</option>
                    </select>
                    <label for="age">Your Credit Rating </label> <!-- clearfix --><div class="clear"></div><!-- /clearfix -->

                    <select id="foreclosure" name="foreclosure">
                        <option>Never Foreclosed</option>
                        <option>Current in Foreclosure</option>
                    </select>
                    <label for="foreclosures">Any foreclosure before? </label> <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
                    
                    <select id="credit_debt" name="credit_debt">
                        <option>$0</option>
                        <option>$100 - $1000</option>
                        <option>$1000 - $2000</option>
                        <option>$2000 - $3000</option>
                        <option>$3000 - $4000</option>
                    </select>
                    <label for="credit_debt">Your credit card debt </label> <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
                    
                </div>      <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
                <input class="submit" type="submit" name="submit_third" id="submit_third" value="" />
                
            </div>      <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
            
            
            <!-- #fourth_step -->
            <div id="fourth_step">
                <h1>CREATE<span> A MORTGAGE</span> PROFILE</h1>

                <div class="form">
                    <h2>Confirmation</h2>
                    
                    <table>
                        <tr><td>Used Property As</td><td></td></tr>
                        <tr><td>State</td><td></td></tr>
                        <tr><td>City</td><td></td></tr>
                        <tr><td>Loan Amount</td><td></td></tr>
                        <tr><td>Down Percent</td><td></td></tr>
                        <tr><td>Credit Rating</td><td></td></tr>
                        <tr><td>Foreclosure</td><td></td></tr>
                        <tr><td>Credit Debt</td><td></td></tr>
                    </table>
                </div>      <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
                <input class="send submit" type="submit" name="submit_fourth" id="submit_fourth" value="" />            
            	</div>
            
        </form>
	</div>
	<div id="progress_bar">
	<div id="progress"></div>
	<div id="progress_text">0% Complete</div>
	</div>

</body>
</html>
