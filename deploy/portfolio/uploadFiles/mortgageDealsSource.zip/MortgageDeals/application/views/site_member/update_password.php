<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />

<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url('assets/css/KeepItSimple.css');?>" />

</head>
<body>

	<!-- header starts-->
	<?php $this->load->view('site_member/includes/_inc_menu_home'); ?>
	<!-- header ends here -->
	</div></div>
	
	<!-- content starts -->
	<div id="content-outer"><div id="content-wrapper" class="container_16">
	
		<!-- main -->
		<div id="main" class="grid_8">
		
		<?php echo $msg;?>
                            <form id="login" action="<?=base_url('member/update_password');?>" method="post">
                                <table border="1" width="100%">
                                    <tr>
                                    <td colspan="2"><font color="red">All fields are required.</font></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">New Password</td>
                                    <td><?php echo form_password('pwd');?>
                                        <?php echo form_error('pwd');?></td>
                                    </tr>
                                    <tr>
                                    <td>Confirm Password</td>
                                    <td><?php echo form_password('pwd_confirm');?>
                                        <?php echo form_error('pwd_confirm');?></td>
                                    </tr>
                                    <tr>
                                    <td></td>
                                    <td><input type="submit" value="Submit" /></td>
                                    </tr>
                                    </table>
				</form>	
		
		<!-- main ends -->
		</div>
	
	<!-- contents end here -->	
	</div></div>

	<!-- footer starts here -->	
	<div id="footer-wrapper" class="container_16">
	
		<?php $this->load->view('site_member/includes/_inc_footer');?>
			
	</div>
	<!-- footer ends here -->

</body>
</html>
