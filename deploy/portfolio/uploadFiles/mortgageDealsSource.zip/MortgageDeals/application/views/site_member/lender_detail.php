<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />
<!--Linking the stylesheet KeepItSimple.css-->
<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url('assets/css/KeepItSimple.css');?>" />

</head>
<body>

	<!-- header starts-->
	<?php $this->load->view('site_member/includes/_inc_menu_home'); ?>
	<!-- header ends here -->
	</div></div>
	
	<!-- content starts -->
	<div id="content-outer"><div id="content-wrapper" class="container_16">
	
		<!-- main -->
		<div id="main" class="grid_8">
		<p><?php echo $msg;?>
                            <form id="login" action="<?=base_url('member/update_offer');?>" method="post">
                                <table border="1" width="100%">
                                    <tr>
                                    <td width="35%">Rate Offer</td>
                                    <td><?php echo $rate_offer;?></td>
                                    </tr>
                                    <tr>
                                    <td>Lender Name</td>
                                    <td><?php echo $lender;?></td>
                                    </tr>
                                    <tr>
                                    <td>Address</td>
                                    <td><?php echo $address;?></td>
                                    </tr>
                                    <tr>
                                    <td>City</td>
                                    <td><?php echo $city;?></td>
                                    </tr>
                                    <tr>
                                    <td>State</td>
                                    <td><?php echo $state;?></td>
                                    </tr>
                                    <tr>
                                    <td>Zip code</td>
                                    <td><?php echo $zipcode;?></td>
                                    </tr>
                                    <tr>
                                    <td>Phone</td>
                                    <td><?php echo $phone;?></td>
                                    </tr>
                                    <tr>
                                    <td>Fax</td>
                                    <td><?php echo $fax;?></td>
                                    </tr>
                                    <tr>
                                    <td>Email</td>
                                    <td><?php echo $email;?></td>
                                    </tr>
                                    <tr>
                                    <td>Offer Option</td>
                                    <td>                                        
                                        <select id="offer_option" name="offer_option">
                                        <option>Accept Offer</option>
                                        <option>Open</option>
                                    </select>
                                    </td>
                                    </tr>
                                    <tr>
                                    <td></td>
                                    <td><input type="submit" value="Submit" /></td>
                                    </tr>
                                    </table>
				</form>	
                        </p>
		</div>
                <!-- main ends -->
	
	<!-- contents end here -->	
	</div></div>

	<!-- footer starts here -->	
	<div id="footer-wrapper" class="container_16">
	
		<?php $this->load->view('site_member/includes/_inc_footer');?>
			
	</div>
	<!-- footer ends here -->

</body>
</html>
