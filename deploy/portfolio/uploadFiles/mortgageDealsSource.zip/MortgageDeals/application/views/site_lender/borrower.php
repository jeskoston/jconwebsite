<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />

<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url('assets/css/KeepItSimple.css');?>" />

</head>
<body>

	<!-- header starts-->
	<?php $this->load->view('site_lender/includes/_inc_menu_home'); ?>
	<!-- header ends here -->
	</div></div>
	
	<!-- content starts -->
	<div id="content-outer"><div id="content-wrapper" class="container_16">
	
		<!-- main -->
		<div id="main" class="grid_8">
		
		<div id="main" class="grid_8">
		
		<p>
                    <fieldset>
                        <legend>Borrower Offer Status</legend>
                        <table border="1" width="100%">
                           
                                    <tr>
                                    <td width="35%">Mortgage Status</td>
                                    <td><?php echo $status;?></td>
                                    </tr>
                                    </table>
                    </fieldset>
                    <fieldset>
                        <legend>Mortgage Profile</legend>
                        <table border="1" width="100%">
                            <tr>
                                    <td width="35%">Use Property As</td>
                                    <td><?php echo $property_usage;?></td>
                                    </tr>
                                    <tr>
                                    <td>Property City</td>
                                    <td><?php echo $property_city;?></td>
                                    </tr>
                                    <tr>
                                    <td>Property State</td>
                                    <td><?php echo $property_state;?></td>
                                    </tr>
                                    <tr>
                                    <td>Property Zip code</td>
                                    <td><?php echo $property_zipcode;?></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Loan Amount</td>
                                    <td><?php echo $loan_amount;?></td>
                                    </tr>
                                    <tr>
                                    <td>Down Payment</td>
                                    <td><?php echo $down_percent;?></td>
                                    </tr>
                                    <tr>
                                    <td>Credit Rating</td>
                                    <td><?php echo $credit_rating;?></td>
                                    </tr>
                                    <tr>
                                    <td>Credit Debt</td>
                                    <td><?php echo $credit_debt;?></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Foreclosure</td>
                                    <td><?php echo $foreclose;?></td>
                                    </tr>
                                    </table>
			
                    </fieldset>
                        <fieldset>
                        <legend>Contact Info</legend>
                        <table border="1" width="100%">
                                    <tr>
                                    <td width="35%">Full Name</td>
                                    <td><?php echo $full_name;?></td>
                                    </tr>
                                    <tr>
                                    <td>Address</td>
                                    <td><?php echo $address;?></td>
                                    </tr>
                                    <tr>
                                    <td>City</td>
                                    <td><?php echo $city;?></td>
                                    </tr>
                                    <tr>
                                    <td>State</td>
                                    <td><?php echo $state;?></td>
                                    </tr>
                                    <tr>
                                    <td>Zip code</td>
                                    <td><?php echo $zipcode;?></td>
                                    </tr>
                                    <tr>
                                    <td>Phone</td>
                                    <td><?php echo $phone;?></td>
                                    </tr>
                                    <tr>
                                    <td>Cell Phone</td>
                                    <td><?php echo $mobile;?></td>
                                    </tr>
                                    <tr>
                                    <td>Email</td>
                                    <td><?php echo $email;?></td>
                                    </tr>
                                    </table>
			
                    </fieldset>
                                
                        </p>
		
		</div>
		</div>
		<!-- main ends -->
	
	<!-- contents end here -->	
	</div></div>

	<!-- footer starts here -->	
	<div id="footer-wrapper" class="container_16">
	
		<?php $this->load->view('site_lender/includes/_inc_footer');?>
			
	</div>
	<!-- footer ends here -->

</body>
</html>
