<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />

<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url('assets/css/KeepItSimple.css');?>" />

</head>
<body>

	<!-- header starts-->
	<?php $this->load->view('site_lender/includes/_inc_menu_home'); ?>
	<!-- header ends here -->
	</div></div>
	
	<!-- content starts -->
	<div id="content-outer"><div id="content-wrapper" class="container_16">
	
		<!-- main -->
		<div id="main" class="grid_8">
                    <form id="purchase" action="<?=base_url('lender/save_purchase');?>" method="post">
                    <table border="1">
                        <tr>
                        <td colspan="2"><h4>Borrower info details will be shown after purchase.</h4></td>
                        </tr>
                        <tr>
                        <td colspan="2"><?php echo $msg;?></td>
                        </tr>
                        <tr>
                        <td>First Name</td>
                        <td><?php echo $first_name;?></td>
                        </tr>
                        <tr>
                        <td>Last Name</td>
                        <td><?php echo $last_name;?></td>
                        </tr>
                        <tr>
                        <td>Purchase Price</td>
                        <td><?php echo "$".$price; ?></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td><input type="submit" value="Submit" /></td>
                        </tr>    
                        <!--tr>
                        <td>row 2, cell 1</td>
                        <td>row 2, cell 2</td>
                        </tr>
                        <tr>
                        <td>row 2, cell 1</td>
                        <td>row 2, cell 2</td>
                        </tr>
                        <tr>
                        <td>row 2, cell 1</td>
                        <td>row 2, cell 2</td>
                        </tr>    
                        <tr>
                        <td>row 2, cell 1</td>
                        <td>row 2, cell 2</td>
                        </tr>
                         <tr>
                        <td>row 2, cell 1</td>
                        <td>row 2, cell 2</td>
                        </tr>
                        <tr>
                        <td>row 2, cell 1</td>
                        <td>row 2, cell 2</td>
                        </tr>    
                        <tr>
                        <td>row 2, cell 1</td>
                        <td>row 2, cell 2</td>
                        </tr-->
                    </table>
                    </form>
		
		<!-- main ends -->
		</div>
	
	<!-- contents end here -->	
	</div></div>

	<!-- footer starts here -->	
	<div id="footer-wrapper" class="container_16">
	
		<?php $this->load->view('site_lender/includes/_inc_footer');?>
			
	</div>
	<!-- footer ends here -->

</body>
</html>
