<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />

<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url('assets/css/KeepItSimple.css');?>" />

</head>
<body>

	<!-- header starts-->
	<?php $this->load->view('site_lender/includes/_inc_menu_home'); ?>
	<!-- header ends here -->
	</div></div>
	
	<!-- content starts -->
	<div id="content-outer"><div id="content-wrapper" class="container_16">
	
		<!-- main -->
		<div id="main" class="grid_8">
		<!-- start display html table -->
                <table cellpadding=2 cellspacing=2 border=1 width="100%" height=20px style='border-collapse: collapse'  bordercolor="#C0C0C0">
                <tr>
                <td width="10px">No.</td>
                <td width="150px">Borrower</td>
                <td width="100px">City</td>
                <td>Zip Code</td>
                <td>Cost</td>
                <td width="30px"></td>
                </tr>
                <tr>
                <?php 
                    if (is_array($leads))
                    {
                        $i = 0;
                        foreach ($leads as $row)
                        {
                            echo '<td>'.++$i.'</td>
                            <td>'.$row->first_name." ".$row->last_name.'</td>
                            <td>'.$row->city.'</td>	     
                            <td>'.$row->zipcode.'</td> 	
                            <td>'."$15.00".'</td>  
                            <td><a href=new_lead/purchase?borrower='.$row->member_id.'>'.'Buy'.'</a></td>   			 

                            </tr>';
                        }// end foreach
                    }
                    else echo "No records found.";
             ?>
                </tr>
                </table>
                <!-- end display html table -->
		
		<!-- main ends -->
		</div>
	
	<!-- contents end here -->	
	</div></div>

	<!-- footer starts here -->	
	<div id="footer-wrapper" class="container_16">
	
		<?php $this->load->view('site_lender/includes/_inc_footer');?>
			
	</div>
	<!-- footer ends here -->

</body>
</html>
