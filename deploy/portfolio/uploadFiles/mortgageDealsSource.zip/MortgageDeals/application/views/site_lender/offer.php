<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />

<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url('assets/css/KeepItSimple.css');?>" />

</head>
<body>

	<!-- header starts-->
	<?php $this->load->view('site_lender/includes/_inc_menu_home'); ?>
	<!-- header ends here -->
	</div></div>
	
	<!-- content starts -->
	<div id="content-outer"><div id="content-wrapper" class="container_16">
	
		<!-- main -->
		<div id="main" class="grid_8">
		
		<p><?php echo $msg;?>
                            <form id="login" action="<?=base_url('lender/save_offer');?>" method="post">
                                <table border="1" width="100%">
                                    <tr>
                                    <td colspan="2"><b>Borrower Info.</b></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Full Name</td>
                                    <td><?php echo $full_name; ?></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Email</td>
                                    <td><?php echo $email; ?></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Offer Rate</td>
                                    <td><?php echo form_input('rate_offer', set_value('fullname'));?>
                                        <?php echo form_error('rate_offer');?></td>
                                    </tr>
                                    <tr>
                                    <td></td>
                                    <td><input type="submit" value="Submit" /></td>
                                    </tr>
                                    </table>
				</form>	
                        </p>
		
		</div>
                <!-- main ends -->
	
	<!-- contents end here -->	
	</div></div>

	<!-- footer starts here -->	
	<div id="footer-wrapper" class="container_16">
	
		<?php $this->load->view('site_lender/includes/_inc_footer');?>
			
	</div>
	<!-- footer ends here -->

</body>
</html>
