<div id="header-wrap"><div id="header" class="container_16">						
		
	<h1 id="logo-text"><a href="<?=base_url('lender');?>" title="">Mortgage Deals</a></h1>
	<p id="intro">make it simple...</p>
	<!-- navigation -->
	<div  id="nav">
            <ul>
              <li><a ><?php echo "<font color=green>Credit Available: $".$this->session->userdata('credit_left')."</font>"; ?></a></li>
              <li><a href="<?=base_url('lender');?>">My Leads</a></li>
              <li><a href="<?=base_url('lender/new_lead');?>">New Leads</a></li>
              <li id="current"><a href="<?=base_url('lender/my_account');?>">My Account</a></li>
              <li><a href="<?=base_url('lender/logout');?>">Logout</a></li>
            </ul>		
        </div>		
		
              <div id="header-image"></div> 		
		
                <form id="quick-search" action="#" method="get" >
                    <p>
			<label for="qsearch">Search:</label>
			<input class="tbox" id="qsearch" type="text" name="qsearch" value="Search..." title="Start typing and hit ENTER" />
			<input class="btn" alt="Search" type="image" name="searchsubmit" title="Search" src="<?=base_url()?>assets/images/search.gif" />
                    </p>
		</form>					