<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />

<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url('assets/css/KeepItSimple.css');?>" />

</head>
<body>

	<!-- header starts-->
	<?php $this->load->view('site_lender/includes/_inc_menu_home'); ?>
	<!-- header ends here -->
	</div></div>
	
	<!-- content starts -->
	<div id="content-outer"><div id="content-wrapper" class="container_16">
	
		<!-- main -->
		<div id="main" class="grid_8">
		
		<p><?php echo $msg;?>
                            <form id="login" action="<?=base_url('lender/save_add_fund');?>" method="post">
                                <table border="1" width="100%">
                                    <tr>
                                    <td colspan="2"><font color="red">All fields are required.</font></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Name On Card</td>
                                    <td><?php echo form_input('fullname', set_value('fullname'));?>
                                        <?php echo form_error('fullname');?></td>
                                    </tr>
                                    <tr>
                                    <td>Card Number</td>
                                    <td><?php echo form_input('card_number', set_value('card_number'));?>
                                        <?php echo form_error('card_number');?></td>
                                    </tr>
                                    <tr>
                                    <td>Card Type</td>
                                    <td><select id="card_type" name="card_type">
                                        <option>Visa</option>
                                        <option>Master Card</option>
                                        <option>American Express</option>
                                        </select>  
                                    </tr>
                                    <tr>
                                    <td>Expired</td>
                                    <td>
                                        <select id="card_type" name="month">
                                        <option>01</option>
                                        <option>02</option>
                                        <option>03</option>
                                        <option>04</option>
                                        <option>05</option>
                                        <option>06</option>
                                        <option>07</option>
                                        <option>08</option>
                                        <option>09</option>
                                        <option>10</option>
                                        <option>11</option>
                                        <option>12</option>
                                        </select>
                                        <select id="card_type" name="year">
                                        <option>2014</option>
                                        <option>2015</option>
                                        <option>2016</option>
                                        <option>2017</option>
                                        <option>2018</option>
                                        <option>2019</option>
                                        <option>2020</option>
                                        </select>
                                    </td>
                                    </tr>
                                    <tr>
                                    <td>Security Code</td>
                                    <td><?php echo form_input('secure_code', set_value('secure_code'));?>
                                        <?php echo form_error('secure_code');?></td>
                                    </tr>
                                    <tr>
                                    <td>Amount</td>
                                    <td><?php echo form_input('amount', set_value('amount'));?>
                                        <?php echo form_error('amount');?></td>
                                    </tr>
                                    <tr>
                                    <td></td>
                                    <td><input type="submit" value="Submit" /></td>
                                    </tr>
                                    </table>
				</form>	
                        </p>
		
		</div>
                <!-- main ends -->
	
	<!-- contents end here -->	
	</div></div>

	<!-- footer starts here -->	
	<div id="footer-wrapper" class="container_16">
	
		<?php $this->load->view('site_lender/includes/_inc_footer');?>
			
	</div>
	<!-- footer ends here -->

</body>
</html>
