<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />

<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url('assets/css/screen.css');?>" />

</head>
<body>

	<!-- header starts-->
	<?php $this->load->view('includes/_inc_header_sign_up'); ?>
	<!-- header ends here -->
	</div></div>
	
	<!-- content starts -->
	<div id="content-outer"><div id="content-wrapper" class="container_16">
	
		<!-- main -->
		<div id="main" class="grid_8">
				
			<a name="TemplateInfo"></a>
			<h2>Create a Profile</h2><br>
                        Complete this form to create your profile. Your information will be kept confidential.	
                        <p><?php echo $msg;?>
                            <form id="login" action="<?=base_url('site/save_profile');?>" method="post">
                                <table border="1" width="100%">
                                    <tr>
                                    <td colspan="2"><font color="red">All fields are required.</font></td>
                                    </tr>
                                    <tr>
                                    <td width="35%">Email Address</td>
                                    <td><?php echo form_input('email', set_value('email'));?>
                                        <?php echo form_error('email');?></td>
                                    </tr>
                                    <tr>
                                    <td>Password</td>
                                    <td><?php echo form_password('pwd', set_value('pwd'));?>
                                        <?php echo form_error('pwd');?></td>
                                    </tr>
                                    <tr>
                                    <td>Confirm Password</td>
                                    <td><?php echo form_password('pwd_confirm', set_value('confirm_pwd'));?>
                                        <?php echo form_error('pwd_confirm');?></td>
                                    </tr>
                                    <tr>
                                    <td>First Name</td>
                                    <td><?php echo form_input('first_name', set_value('first_name'));?>
                                        <?php echo form_error('first_name');?></td>
                                    </tr>
                                    <tr>
                                    <td>Last Name</td>
                                    <td><?php echo form_input('last_name', set_value('last_name'));?>
                                        <?php echo form_error('last_name');?></td>
                                    </tr>
                                    <!--tr>
                                    <td>City</td>
                                    <td><php echo form_input('city', set_value('city'));?>
                                        <php echo form_error('city');?></td>
                                    </tr-->
                                    <tr>
                                    <td></td>
                                    <td><input type="submit" value="Submit" /></td>
                                    </tr>
                                    </table>
				</form>	
                        </p>
			
		
		<!-- main ends -->
		</div>
		
		<!-- left-columns starts -->
		<div id="left-columns" class="grid_8">
		
			<div class="grid_4 alpha">
			<h3>Why?</h3>		
			
				<div class="featured-post">
				
					<p>display contents here</p>					
				
				</div>
				<div class="sidemenu">	
				
				</div>

			</div>
		
		<!-- end left-columns -->
		</div>		
	
	<!-- contents end here -->	
	</div></div>

	<!-- footer starts here -->	
	<div id="footer-wrapper" class="container_16">
	
		<?php $this->load->view('includes/_inc_footer');?>
			
	</div>
	<!-- footer ends here -->

</body>
</html>
