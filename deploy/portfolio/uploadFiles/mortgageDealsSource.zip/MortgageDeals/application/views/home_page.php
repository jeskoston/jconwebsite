<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<title>Mortgage Deals</title>

<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="description" content="Site Description Here" />
<meta name="keywords" content="keywords, here" />
<meta name="robots" content="index, follow, noarchive" />
<meta name="googlebot" content="noarchive" />

<link rel="stylesheet" type="text/css" media="screen" href="<?=base_url('assets/css/screen.css');?>" />

</head>
<body>

	<!-- header starts-->
	<?php $this->load->view('includes/_inc_header_home'); ?>
	<!-- header ends here -->
	</div></div>
	
	<!-- content starts -->
	<div id="content-outer"><div id="content-wrapper" class="container_16">
	
		<!-- main -->
		<div id="main" class="grid_8">
				
			<a name="TemplateInfo"></a>
			<h2>How it works</h2>
				
            <p><strong>Keep It Simple</strong> content go here
            </p>
			
		
		<!-- main ends -->
		</div>
		
		<!-- left-columns starts -->
		<div id="left-columns" class="grid_8">
		
			<div class="grid_4 alpha">
			
				<div class="sidemenu">	
                                <?php echo $msg;?>
				<form id="login" action="<?=base_url('member/login');?>" method="post">
					<h3>Login</h3>
					Email:<br>
					<input type="text" name="email" /><br>
					Password:<br>
					<input type="password" name="pwd" />
					<br>
					<input type="submit" value="Submit" />
					<ul>				
						<li><a href="<?=base_url('site/forgot_password');?>">Lost Password</a> | <a href="<?=base_url('site/create_profile');?>">Sign Up</a></li>
					</ul>
				</form>	
				</div>

			</div>
		
			<div class="grid_4 omega">
		
				<h3>Current Rate</h3>		
			
				<div class="featured-post">
				
					<p>display rate here</p>					
				
				</div>
			
			</div>	
		
		<!-- end left-columns -->
		</div>		
	
	<!-- contents end here -->	
	</div></div>

	<!-- footer starts here -->	
	<div id="footer-wrapper" class="container_16">
	
		<!--Will load the footer from the includes file-->
		<?php $this->load->view('includes/_inc_footer');?>
			
	</div>
	<!-- footer ends here -->

</body>
</html>
