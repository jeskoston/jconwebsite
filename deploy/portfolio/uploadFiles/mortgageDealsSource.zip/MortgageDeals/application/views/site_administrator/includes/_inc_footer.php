<div id="footer-content">
		
		</div>
	
		<div id="footer-bottom">
	
			<p class="bottom-left">			
			&nbsp; &copy;<?php echo (date("Y"));?> all rights reserved &nbsp; &nbsp;
			</p>
		</div>	