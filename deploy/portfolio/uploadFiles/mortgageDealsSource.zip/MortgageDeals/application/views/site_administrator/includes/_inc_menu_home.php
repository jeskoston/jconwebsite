<div id="header-wrap"><div id="header" class="container_16">						
		
		<h1 id="logo-text"><a href="<?=base_url('site_admin/lenders');?>" title="">Mortgage Deals</a></h1>
		<p id="intro">makes it simple...</p>
		<!-- navigation -->
		<div  id="nav">
			<ul>
				<li><a href="<?=base_url('site_admin/lenders');?>">Lenders</a></li>
                                <li><a href="<?=base_url('site_admin/create_lender_login');?>">Create Lender Login</a></li>
				<li><a href="<?=base_url('site_admin/lenders/add');?>">Add Lender</a></li>
                                <li><a href="<?=base_url('site_admin/member');?>">Members</a></li>
                                <li><a href="<?=base_url('site_admin/transaction');?>">Transactions</a></li>
				<!--li><a href="<=base_url('site_admin/my_account');?>">Add Admin Login</a></li-->
				<li><a href="<?=base_url('site_admin/logout');?>">Logout</a></li>
			</ul>		
		</div>		
		
		<div id="header-image"></div> 		
		
		<form id="quick-search" action="#" method="get" >
			<p>
			<label for="qsearch">Search:</label>
			<input class="tbox" id="qsearch" type="text" name="qsearch" value="Search..." title="Start typing and hit ENTER" />
			<input class="btn" alt="Search" type="image" name="searchsubmit" title="Search" src="<?=base_url()?>assets/images/search.gif" />
			</p>
		</form>					