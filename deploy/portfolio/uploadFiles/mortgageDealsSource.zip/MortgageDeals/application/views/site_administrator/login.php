<link rel="stylesheet" href='<?=base_url()?>assets/css/login_style.css' type="text/css" media="screen, projection" />
<div id="login_form">
    <h1>Admin Login!</h1>

    <?php 
        echo validation_errors();
        if(!empty($msg))
        {
                echo "<font color=red>".$msg."</font>";
        }		
        echo form_open('site_admin/login');
        echo "Username<br>";
        echo form_input('username', set_value('username'),'Username');
        echo "Password<br>";
        echo form_password('password', '', 'Password');
        echo form_submit('submit', 'Login');
        echo anchor('site_admin/login', 'Forgot Password');

    ?>
</div>